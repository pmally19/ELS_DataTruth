﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Excel;
using Microsoft.Office.Tools;
using System.Windows.Forms;

namespace ELS_PLUS_ADDIN
{
    public partial class ThisAddIn
    {

        public UserControl userControl;

        private CustomTaskPane myCustomTaskPane;

        public Microsoft.Office.Tools.CustomTaskPane TaskPane
        {
            get
            {
                return myCustomTaskPane;
            }
        }
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            userControl = new UserControl();
            myCustomTaskPane = this.CustomTaskPanes.Add(userControl, "ELS+");
            myCustomTaskPane.Width = 340;
            myCustomTaskPane.Visible = true;
            myCustomTaskPane.VisibleChanged += new EventHandler(MyCustomTaskPane_VisibleChanged);

            //MessageBox.Show("void ThisAddIn_Startup");
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion
        private void MyCustomTaskPane_VisibleChanged(object sender, EventArgs e)
        {
            // Cast sender to CustomTaskPane
            var taskPane = sender as Microsoft.Office.Tools.CustomTaskPane;

            if (taskPane != null)
            {
                Globals.Ribbons.Ribbon1.onChangeTaskPaneVisibility(taskPane.Visible);
            }
        }
    }
}
