from google.oauth2 import service_account
import pandas as pd
import matplotlib.pyplot as plt
import sys
import xlwings as xw
from google.cloud import bigquery

import GCP
import GCP_BigQuery

try:
    arg1 = sys.argv[1]
    arg2 = ""
    arg3 = ""
    arg4 = ""
    if len(sys.argv) > 2:
        arg2 = sys.argv[2]
    if len(sys.argv) > 3:
        arg3 = sys.argv[3]
    if len(sys.argv) > 4:
        arg4 = sys.argv[4]

    if arg1 == "google" and arg2 == "refresh":
        print(GCP.get_all_tables())
    elif arg1 == "google" and arg2 == "columns":
        print(GCP.get_all_columns(arg3))
    elif arg1 == "google" and arg2 == "tabledata":
        arg4 = ",".join(arg4.split("#"))
        sql = f"SELECT {arg4} FROM {arg3}"
        print(GCP.execute_query(sql))
    elif arg1 == "google" and arg2 == "gpt":
        print(arg4)
        response = GCP_BigQuery.get_openai_response_with_cache(arg4, arg3)            

            # Now execute the SQL and save results to the active Excel sheet
        result_message = GCP_BigQuery.execute_and_save_to_excel(response)
    elif arg1 == "google" and arg2 == "prestage-create":
        schema = sys.argv[3]
        table_id = sys.argv[4]
        GCP.upload_selected_excel_to_bigquery(GCP.project_id + "." +schema + "." + table_id)
    elif arg1 == "google" and arg2 == "prestage-refresh":
        print(GCP.get_only_prestage_tables())
    elif arg1 == "google" and arg2 == "prestage-save":
        
        schema = sys.argv[3]
        table_id = sys.argv[4]
        GCP.upload_selected_excel_to_bigquery(GCP.project_id + "." +schema + "." + table_id)
    elif arg1 == "google" and arg2 == "prestage_show_data":
        sql = f"SELECT * FROM {arg3}"
        GCP.execute_query(sql)
        print(arg3)
    elif arg1 == "google" and arg2 == "save":
        table_id = sys.argv[3]
        GCP.upload_selected_excel_to_bigquery(GCP.project_id + "." + GCP.save_dataset_id + "." + table_id)
    elif arg1 == "google" and arg2 == "previous":
        arg3 = sys.argv[3]
        (name, version) = GCP.get_name_version(arg3)
        if version == 0:
            print("Error#You have no previous data")
        else:
            version = version - 1
            new_name = GCP.execute_previous(name, version)
            print(new_name)

    elif arg1 == "google" and arg2 == "commit":
        table_id = sys.argv[3]
        GCP.upload_selected_excel_to_bigquery(GCP.project_id + "." + GCP.commit_dataset_id + "." + table_id)
    else:
        print("Error#Invalid arguments" + sys.argv[1] + " " + sys.argv[2])

except Exception as e:
    print("Error:", e)

