from google.oauth2 import service_account
import pandas as pd
import matplotlib.pyplot as plt
import sys
import xlwings as xw
from google.cloud import bigquery

# Initialize cache
cache = {}
service_account_info = {
  "type": "service_account",
  "project_id": "lyrical-country-397623",
  "private_key_id": "26653c08607b502f95741c846830104efa7ae49c",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCaWY/4dGZ7OklG\nVIyIEPdEXZWY0BVwnnFlIhAJjrQ05qyx4mIi1bn0yFUz+ymO0qh8CkrKBFnE/Orl\n8zBfFtMN1cDnL0hQgcV7YDi1z3kt5Ho7W/An9MyEu4juzHV94/Yvbzb3Ez55LLwo\nD2ujl3rpmqU8s+DpY23U/Yt3cYE3AEC+JOyJifIcGfjL6pbHILW6jYHr3lGdcVxJ\nqXmYB1r9zKFn7LK8x79wzQObO0YC3Ooo+63JYi1YIdBu0dJj0YIgCpyIGM6EI+pJ\nh6YzVzDvxT7mws4ir8g50xSE4vpz7v/vJeZ+3PAm7mhOt/Q23bKXEHklt3pGsZDS\nX4SkJ2lNAgMBAAECggEAEHIwk/GbJdAtFJBXtPvRzPgHw5OQZUKMpJD/knUhIG3f\nwshzWnDZcoqSAYrmf7BUgXr7QxE5m3KzeLLz2X3uGRBIkJmKJAHfz+iNwlmL+Oba\nW07NhQRhclclHQSuFC7hAWbhPWxQgMrSdZZHCtROJWvz5UbpVRTiFAq7/IsckIaM\n2IP2fVDdZwvzkxbVvzQzyrisJ1YbCK6qsuees+B4cUknaEGs4rVYxn4//g0svTkY\noFvycpJFgrScUezvkTW5pqTnCeNwATyS90zKAFTAaHOGu3WucMsJBvi+WST5asbc\n/1CmDd6tVR0BuJ2D8vampcs+5sXGD4FZ6itcSoVvRQKBgQDZL/AYBde73k4R+I6O\ne+wA3AIc4VD398JY2lIV7wMC2Yg4BzEV3ngBvlrbnjbri9OnasG/YAfPM5ikt0tf\namTkr/JH6IHb4E5GJ2m/CrHXQiIZptUlFnDbS9kOu1XjV/Z5iyUa/xT4ZcKKWPPa\nFaIrGN9EC5WNWpa0Te7n2BSKfwKBgQC17uMTvlcCz1y5cEBStoyxGJkAE/bhz9qp\nfGF8Pb37Lf8+neEl2r81Lercfk/0dgQGFwiX6Radv9yb6jecbpSUeqtsiJ9rmEPo\ni9rEQOyXVW9DpEofJoOPe1kI6FWHci+Y5ctLNIbsujrnZUdKBwjzvCb9hi7Mpp5G\nFJQoAFMuMwKBgAnjjOMLIQ+Ex7k5wAPs0IoZel8mQzGHLmotRp+JCnIOxY0Hhsyg\nHIa3zBtD0OxYqYJt8fRswu5EQyb80Ym+pmljOXzcsUz5oZbAJKh2LDLI6BSS7BGM\nPAdAJNnu3bJERwyxsTbRdnr45yq1ciTz5zZfI4tNm7mb7lC3W7FivUyxAoGAUWNK\nxlxSBHnLW1GyFM6BZgBBAd3shdw8T7HK0o+0W5eaJeLvA8Y1345pELaZAh2Bc0/+\nkia97VgVUtKWii6V3U57PZRo7PMy/ecCuOTqclDP84yddA4AsMFXdTqqeGtGi7nR\nFhWrfl9ZVobiO2WmRZMYRjYu3XJ0P5mZJcPvci0CgYAWbNfhZFCPdkpSkdmo6+WR\npmjvhoxIf7MP1QmGxtc0GOh1I2QyFy6W5xj2VaeBEJXRhju4X99Ui7V/X0iL8ui2\n0iLPh3Sl0DpnyZBvKfZ5q6JCo7ojEQX6QhFejT9P9aMaIG7duAbE2ZwZoU0smOYI\n6lZZ+lqtMoa/ThbZpjD19w==\n-----END PRIVATE KEY-----\n",
  "client_email": "test-isai-service@lyrical-country-397623.iam.gserviceaccount.com",
  "client_id": "111104737233191547996",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/test-isai-service%40lyrical-country-397623.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}


credentials = service_account.Credentials.from_service_account_info(
    service_account_info,
    scopes=["https://www.googleapis.com/auth/cloud-platform"],
)

project_id = "lyrical-country-397623"
save_dataset_id = "Query_Save"
commit_dataset_id = "Commit"

client = bigquery.Client(credentials=credentials, project=credentials.project_id)


def get_all_tables():
    dataset_list = list(client.list_datasets())
    table_list = ""
    for dataset in dataset_list:
#        if dataset.dataset_id == "Commit" or dataset.dataset_id == "Prestage":
#            continue
        tables = list(client.list_tables(dataset.dataset_id))
        for table in tables:
            table_list = table_list + "#" + f"{dataset.dataset_id}.{table.table_id}"
    return table_list


def get_only_prestage_tables():
    dataset_list = list(client.list_datasets())
    table_list = ""
    for dataset in dataset_list:
        if dataset.dataset_id == "Prestage":
            tables = list(client.list_tables(dataset.dataset_id))
            for table in tables:
                table_list = table_list + "#" + f"{dataset.dataset_id}.{table.table_id}"
    return table_list


def get_all_columns(table_name):
    data_split = table_name.split(".")
    dataset_id = data_split[0]
    table_id = data_split[1]
    dataset_ref = client.get_dataset(dataset_id)
    table_ref = dataset_ref.table(table_id)
    table = client.get_table(table_ref)
    schema = table.schema
    result = ""
    for column in schema:
        result += "#" + column.name

    return result


# columns = "C_CUSTKEU, C_NAME"
def get_table_data(table_name):
    data_split = table_name.split(".")
    dataset_id = data_split[1]
    table_id = data_split[2]
    dataset_ref = client.get_dataset(dataset_id)
    table_ref = dataset_ref.table(table_id)
    table = client.get_table(table_ref)
    sql = "SELECT * from lyrical-country-397623.Query_Save.Analytics_Customer_Orders_v0"
    results = client.query(sql).result()
    for row in results:
        print(row)
    return
    fields = table.schema[:2]
    rows_iter = client.list_rows(table_name)
    rows = list(rows_iter)
    sql = "SELECT * from {}".format(table_name)
    df = client.list_rows(table_name).to_dataframe(create_bqstorage_client=True)
    # field_names = [field.name for field in rows_iter.schema]
    print(df)
    return


# get_table_data("lyrical-country-397623.Query_Save.Analytics_Customer_Orders_v0")


def get_saved_tables(set_id):
    dataset_ref = client.dataset(set_id)
    tables = client.list_tables(dataset_ref)
    list = []
    for table in tables:
        list.append(table.table_id)
    return list


def interpret_query(table_name, question, fields):
    keyword1 = "C_ACCTBAL"
    keyword2 = "O_TOTALPRICE"
    question = question.replace("#", " ")
    field_names = fields.split(",")
    temp = fields.split(",")
    if keyword2 in fields:
        sale_price = keyword2
    else:
        sale_price = keyword1

    if question == "average sale price":
        sql = f"SELECT AVG(`{sale_price}`) as Average_Sale_Price FROM `{table_name}`"
    elif question == "top 10 sales":
        sql = "SELECT "
        if keyword2 in field_names:
            sql += f"SUM(`{keyword2}`) AS Actual_Balance,"
            field_names.remove(keyword2)
        if keyword1 in field_names:
            sql += f"SUM(`{keyword1}`) AS Total_Price,"
            field_names.remove(keyword1)
        print(f"temp: {temp}")
        sql += ",".join(field_names)
        sql += f" FROM `{table_name}` GROUP BY "
        sql += ",".join(field_names)
        sql += " ORDER BY "
        if keyword2 in temp:
            sql += "Actual_Balance,"
        if keyword1 in temp:
            sql += "Total_Price"
        if sql[len(sql) - 1] == ",":
            sql = sql[: (len(sql) - 1)]
        sql += " DESC LIMIT 10"
    elif question == "total sales":
        sql = f"SELECT SUM(`{sale_price}`) as Total_Sales FROM `{table_name}`"
    elif question == "list the column names":
        sql = f"SELECT * FROM `{table_name}` LIMIT 0"
    elif question == "list the total rows":
        sql = f"SELECT COUNT(*) AS Total_Rows FROM `{table_name}`"
    else:
        print("Query not recognized")
    print(sql)
    return sql


# Function to execute the query
def execute_query(sql):
    query_job = client.query(sql)
    results = query_job.result()
    sheet = xw.sheets.active
    sheet.clear_contents()
    xlapp = xw.apps.active
    rng = xlapp.selection
    res = ""
    # if len(list(results.schema)) == 1 and results.total_rows == 1:
    #     for row in results:
    #         res = row[0]
    #         rng.value = row[0]
    #     return 1
    # else:
    field_types = [field.field_type for field in results.schema]
    df = results.to_dataframe()
    # sheet[rng.address].options(
    #     pd.DataFrame, header=1, index=False, expand="table"
    # ).value = df
    sheet['A1'].options(pd.DataFrame, header=1, index=False, expand='table').value = df
    # sheet.autofit()
    res = ",".join(df.columns) + "#" + ",".join(field_types)
    # print(f"with column:\n{len(df.columns)}")
    # print(f"with column:\n{len(field_types)}")
    return res


def execute_previous(name, version):
    execute_clear()
    new_name = "Query_Save." + name + "_v" + str(version)
    sql = f"SELECT * FROM `{new_name}`"
    res = execute_query(sql)
    return new_name


def execute_clear():
    sheet = xw.sheets.active
    try:
        rng = get_table_range()
        sheet.range(rng).clear_contents()
    except Exception as e:
        pass


def get_frame_from_excel():
    sheet = xw.sheets.active
    rng = get_table_range()
    df = (
        sheet[rng.address]
        .options(pd.DataFrame, header=1, index=False, expand="table")
        .value
    )
    return df


def get_table_selected_range():
    wb = xw.books.active
    selected_range = wb.selection
    return selected_range


def get_frame_from_selected_range():
    sheet = xw.sheets.active
    rng = get_table_selected_range()
    # wb = xw.books.active
    # df = wb.selection.options(pd.DataFrame, header=1, index=False, expand="table").value
    df = sheet[rng.address].options(pd.DataFrame, header=1, index=False).value
    return df


def get_range_end(fc):
    ws = xw.sheets.active
    er = ws.range((ws.cells.last_cell.row, fc)).end("up").row
    ec = ws.range((er, ws.cells.last_cell.column)).end("left").row
    return (er, ec)


def get_range_start():
    ws = xw.sheets.active
    row_cell = ws.api.Cells.Find(
        What="*",
        After=ws.api.Cells(ws.api.Rows.Count, ws.api.Columns.Count),
        LookAt=xw.constants.LookAt.xlPart,
        LookIn=xw.constants.FindLookIn.xlFormulas,
        SearchOrder=xw.constants.SearchOrder.xlByRows,
        SearchDirection=xw.constants.SearchDirection.xlNext,
        MatchCase=False,
    )
    column_cell = ws.api.Cells.Find(
        What="*",
        After=ws.api.Cells(ws.api.Rows.Count, ws.api.Columns.Count),
        LookAt=xw.constants.LookAt.xlPart,
        LookIn=xw.constants.FindLookIn.xlFormulas,
        SearchOrder=xw.constants.SearchOrder.xlByColumns,
        SearchDirection=xw.constants.SearchDirection.xlNext,
        MatchCase=False,
    )
    return (row_cell.Row, column_cell.Column)


def get_table_range():
    ws = xw.sheets.active
    (fr, fc) = get_range_start()
    (er, ec) = get_range_end(fc)
    return ws.range((fr, fc), (er, ec))


# print(get_table_selected_range())
# print(get_table_range())


def get_name_version(tableName):
    version = 0
    name = tableName
    if "_v" in name:
        temp = name.split("_v")
        name = temp[0]
        version = int(temp[1])
    elif "_V" in name:
        temp = name.split("_V")
        name = temp[0]
        version = int(temp[1])
    return (name, version)






def upload_selected_excel_to_bigquery(table_id):
    # Fetch selected data from Excel
    wb = xw.books.active
    sheet = xw.sheets.active
    selected_range = sheet.range(wb.selection.address)
    df = selected_range.options(pd.DataFrame, header=1, index=False).value

    # Check if DataFrame is empty
    if df.empty:
        print("No data selected in Excel. Please select a valid range.")
        return


    # Infer schema for BigQuery from DataFrame
    schema = []
    for column, dtype in zip(df.columns, df.dtypes):
        if pd.api.types.is_integer_dtype(dtype):
            schema.append(bigquery.SchemaField(column, "INTEGER"))
        elif pd.api.types.is_float_dtype(dtype):
            schema.append(bigquery.SchemaField(column, "FLOAT"))
        elif pd.api.types.is_bool_dtype(dtype):
            schema.append(bigquery.SchemaField(column, "BOOLEAN"))
        elif pd.api.types.is_datetime64_any_dtype(dtype):
            schema.append(bigquery.SchemaField(column, "TIMESTAMP"))
        else:
            schema.append(bigquery.SchemaField(column, "STRING"))

    # Configure the BigQuery load job
    job_config = bigquery.LoadJobConfig(
        schema=schema, 
        write_disposition=bigquery.WriteDisposition.WRITE_TRUNCATE 
    )
    # Load data into BigQuery
    job = client.load_table_from_dataframe(df, table_id, job_config=job_config)
    job.result()  # Wait for the job to complete
    # Get the data from the selected range
    
    print(f"{table_id}")


