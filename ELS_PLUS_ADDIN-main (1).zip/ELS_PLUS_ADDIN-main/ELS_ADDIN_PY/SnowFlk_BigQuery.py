import warnings
import snowflake.connector
import openai
import pandas as pd
import win32com.client as win32

# Suppress warnings
warnings.filterwarnings('ignore')

# Snowflake connection details
conn = snowflake.connector.connect(
    user='bw4guys',
    password='Oranges@1234',
    account='qvjfyzk-rk57999',
    warehouse='COMPUTE_WH',
    database='ELSDB',
)


# OpenAI API key
openai.api_key = "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"

def list_all_tables():
    cursor = conn.cursor()
    cursor.execute("SHOW TABLES")
    table_list = [row[1] for row in cursor]
    cursor.close()
    return table_list

def fetch_data_from_table(table_name):
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM {table_name} LIMIT 1000")
    df = cursor.fetch_pandas_all()
    cursor.close()
    return df

def ask_openai_with_context_for_table(question, table_name):
    df = fetch_data_from_table(table_name)

    numeric_cols = [col for col in df.columns if df[col].dtype in ['float64', 'int64']]
    context_list = [f"Table Name: {table_name}", f"Columns: {', '.join(df.columns)}"]

    for col in numeric_cols:
        context_list.append(f"For column '{col}', the average value is {df[col].mean():.2f}.")

    categorical_cols = [col for col in df.columns if df[col].dtype == 'object']
    for col in categorical_cols:
        top_values = df[col].value_counts().nlargest(5).index.tolist()
        context_list.append(f"For column '{col}', some frequent values are: {', '.join(top_values)}.")

    df_context = ' '.join(context_list)
    full_prompt = df_context + "\nQuestion: " + question + "\n\nWrite a Snowflake SQL to fetch the desired result:"

    response = openai.Completion.create(
      model="gpt-3.5-turbo-instruct",
      prompt=full_prompt,
      max_tokens=2048
    )
    return response.choices[0].text.strip()

def ask_openai_for_snowflake_function(query, table_name):
    context = f"You are working with a Snowflake table named '{table_name}'. Given the request, which Snowflake function or operation would be suitable?\n"
    full_prompt = context + query
    response = openai.Completion.create(
      model="text-davinci-003",
      prompt=full_prompt,
      max_tokens=200
    )
    return response.choices[0].text.strip()

# Dictionary to cache previous results
cache = {}

def get_openai_response_with_cache(question, table_name):
    # Check if the question is in cache
    if question in cache:
        return cache[question]

    # If not in cache, fetch the response from OpenAI
    response = ask_openai_with_context_for_table(question, table_name)
    if not response:
        response = ask_openai_for_snowflake_function(question, table_name)

    # Store the response in cache and return it
    cache[question] = response
    return response

def execute_and_save_to_excel(sql):
    """Execute the provided SQL query and save results to the active Excel sheet."""
    try:
        cursor = conn.cursor()
        cursor.execute(sql)
        df = cursor.fetch_pandas_all()
        cursor.close()

        # Connect to the running instance of Excel
        excel = win32.gencache.EnsureDispatch('Excel.Application')
        workbook = excel.ActiveWorkbook
        sheet = workbook.ActiveSheet
        
        # Clear existing data
        sheet.Cells.Clear()

        # Write column headers
        columns = df.columns.tolist()
        for col_num, col_name in enumerate(columns, 1):
            sheet.Cells(1, col_num).Value = col_name

        # Write data rows
        for row_num, row in enumerate(df.itertuples(index=False), 2):
            for col_num, cell_value in enumerate(row, 1):
                sheet.Cells(row_num, col_num).Value = cell_value
        
        return "Results saved to the active Excel sheet."
    except Exception as e:
        return f"Error executing query: {e}"

def chat_box():
    tables = list_all_tables()
    print("Available tables:")
    for idx, table in enumerate(tables, 1):
        print(f"{idx}. {table}")

    choice = int(input("Select a table by number (or 'exit' to quit): ").strip())
    if choice < 1 or choice > len(tables):
        print("Invalid choice!")
        return
    selected_table = tables[choice - 1]

    while True:
        user_input = input("Enter your query or describe the operation you want to perform (or 'exit' to quit): ").strip()
        if user_input == 'exit':
            break
        else:
            response = get_openai_response_with_cache(user_input, selected_table)
            print(f"Generated SQL: {response}")

            # Now execute the SQL and save results to the active Excel sheet
            result_message = execute_and_save_to_excel(response)
            print(result_message)

# Start the chatbox
#chat_box()

# Close the Snowflake connection
#conn.close()
