import snowflake.connector
import pandas as pd
import xlwings as xw
import matplotlib.pyplot as plt
from snowflake.connector.pandas_tools import write_pandas

import sys
# Connect to Snowflake
conn = snowflake.connector.connect(
    user='bw4guys',
    password='Oranges@1234',
    account='QVXCJRC-JC72174',
    warehouse='COMPUTE_WH',
    database='SNOWFLAKE_SAMPLE_DATA',
)

def get_all_tables():
    cursor = conn.cursor()
    cursor.execute("SHOW TABLES")
    tables = cursor.fetchall()
    table_list = ""
    for table in tables:
        table_name = table[1]
        schema_name = table[3]
#        if schema_name == "COMMIT" or schema_name == "PRESTAGE":
#            continue
        table_list += f"#{schema_name}.{table_name}"
    return table_list

# Get only tables from 'Prestage'
def get_only_prestage_tables():
    cursor = conn.cursor()
    cursor.execute("SHOW TABLES IN SCHEMA PRESTAGE")
    tables = cursor.fetchall()
    table_list = ""
    for table in tables:
        table_name = table[1]
        table_list += f"#Prestage.{table_name}"
    return table_list


def get_all_columns(table_name):
    # Check if table_name contains a period
    
    # Split the table name to get the schema and table name
    schema_name, table_id = table_name.split(".", 1)  # Use '1' to ensure only one split

    # Create a cursor object
    cursor = conn.cursor()

    try:
        # Construct the query to get column information
        query = f"""
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = '{schema_name}'
          AND TABLE_NAME = '{table_id}'
        """

        # Execute the query
        cursor.execute(query)
        
        # Fetch all results
        columns = cursor.fetchall()
        
        # Format the column list
        result = ""
        for column in columns:
            result += "#" + column[0]        
    finally:
        # Close the cursor and connection
        cursor.close()
        conn.close()

    return result

# Query and retrieve data from a table
def get_table_data(table_name):
    schema_name, table_name = table_name.split(".")
    query = f"SELECT * FROM {schema_name}.{table_name} LIMIT 100"
    cursor = conn.cursor()
    cursor.execute(query)
    rows = cursor.fetchall()
    for row in rows:
        print(row)

def execute_query(sql):
    cursor = conn.cursor()
    
    # Execute the query
    cursor.execute(sql)
    
    # Fetch all results
    results = cursor.fetchall()
    
    # Get column names and types
    col_names = [col[0] for col in cursor.description]
    col_types = [col[1] for col in cursor.description]
    
    # Convert results to DataFrame
    df = pd.DataFrame(results, columns=col_names)
    
    # Write to Excel
    sheet = xw.sheets.active
    sheet.clear_contents()
    xlapp = xw.apps.active
    rng = xlapp.selection
    
    # Output DataFrame to the selected range
    sheet['A1'].options(pd.DataFrame, header=1, index=False, expand='table').value = df
    
    # Return the column names and types as a string
    res = ",".join(col_names) + "#" + ",".join(str(t) for t in col_types)
    
    # Close connections
    cursor.close()
    conn.close()
    
    return res


def get_saved_tables(set_id):
    sql = f"""
    SELECT TABLE_NAME 
    FROM INFORMATION_SCHEMA.TABLES 
    WHERE TABLE_SCHEMA = '{set_id}'
    """
    cursor = conn.cursor()
    cursor.execute(sql)
    tables = cursor.fetchall()
    return [table for (table,) in tables]

# Interpret query based on question and table structure
def interpret_query(table_name, question, fields):
    keyword1 = "C_ACCTBAL"
    keyword2 = "O_TOTALPRICE"
    field_names = fields.split(",")

    if "total sales" in question:
        sale_price = keyword2 if keyword2 in fields else keyword1
        sql = f"SELECT SUM({sale_price}) AS Total_Sales FROM {table_name}"
    elif "average sale price" in question:
        sale_price = keyword2 if keyword2 in fields else keyword1
        sql = f"SELECT AVG({sale_price}) AS Average_Sale_Price FROM {table_name}"
    elif "list the column names" in question:
        sql = f"SHOW COLUMNS IN {table_name}"
    elif "list the total rows" in question:
        sql = f"SELECT COUNT(*) AS Total_Rows FROM {table_name}"
    else:
        print("Query not recognized")
        return None

    print(sql)
    return sql


def execute_previous(name, version):
    execute_clear()
    new_name = "QUERY_SAVE." + name + "_v" + str(version)
    sql = f"SELECT * FROM {new_name}"
    res = execute_query(sql)
    return new_name

def execute_clear():
    sheet = xw.sheets.active
    try:
        rng = get_table_range()
        sheet.range(rng).clear_contents()
    except Exception as e:
        pass

def get_frame_from_excel():
    sheet = xw.sheets.active
    rng = get_table_range()
    df = sheet[rng.address].options(pd.DataFrame, header=1, index=False, expand="table").value
    return df


def get_table_selected_range():
    wb = xw.books.active
    selected_range = wb.selection
    return selected_range

def get_frame_from_selected_range():
    sheet = xw.sheets.active
    rng = get_table_selected_range()
    df = sheet[rng.address].options(pd.DataFrame, header=1, index=False).value
    return df

def get_range_end(fc):
    ws = xw.sheets.active
    er = ws.range((ws.cells.last_cell.row, fc)).end("up").row
    ec = ws.range((er, ws.cells.last_cell.column)).end("left").row
    return (er, ec)

def get_range_start():
    ws = xw.sheets.active
    row_cell = ws.api.Cells.Find(
        What="*",
        After=ws.api.Cells(ws.api.Rows.Count, ws.api.Columns.Count),
        LookAt=xw.constants.LookAt.xlPart,
        LookIn=xw.constants.FindLookIn.xlFormulas,
        SearchOrder=xw.constants.SearchOrder.xlByRows,
        SearchDirection=xw.constants.SearchDirection.xlNext,
        MatchCase=False,
    )
    column_cell = ws.api.Cells.Find(
        What="*",
        After=ws.api.Cells(ws.api.Rows.Count, ws.api.Columns.Count),
        LookAt=xw.constants.LookAt.xlPart,
        LookIn=xw.constants.FindLookIn.xlFormulas,
        SearchOrder=xw.constants.SearchOrder.xlByColumns,
        SearchDirection=xw.constants.SearchDirection.xlNext,
        MatchCase=False,
    )
    return (row_cell.Row, column_cell.Column)

def get_table_range():
    ws = xw.sheets.active
    (fr, fc) = get_range_start()
    (er, ec) = get_range_end(fc)
    return ws.range((fr, fc), (er, ec))

def save_selected_excel_to_snowflake( table_name, schema=None, database=None):
    # Fetch selected data from Excel

    wb = xw.books.active
    sheet = xw.sheets.active
    selected_range = sheet.range(wb.selection.address)
    df = selected_range.options(pd.DataFrame, header=1, index=False).value

    # Check if DataFrame is empty
    if df.empty:
        print("No data selected in Excel. Please select a valid range.")
        return

    # Connect to Snowflake

    table_name = table_name.upper()

    cursor = conn.cursor()
        # Switch to the correct schema
        # Set the database and schema context

    if database:
        cursor.execute(f"USE DATABASE {database}")
    if schema:
        cursor.execute(f"USE SCHEMA {schema}")
#    cursor.execute(f"DESCRIBE TABLE {schema}.{table_name}")

    # Dynamically create the CREATE TABLE statement based on the DataFrame's schema
    def infer_snowflake_type(dtype):
        if pd.api.types.is_integer_dtype(dtype):
            return "INTEGER"
        elif pd.api.types.is_float_dtype(dtype):
            return "FLOAT"
        elif pd.api.types.is_bool_dtype(dtype):
            return "BOOLEAN"
        elif pd.api.types.is_datetime64_any_dtype(dtype):
            return "TIMESTAMP"
        else:
            return "STRING"

    # Generate the CREATE TABLE SQL
    column_definitions = ", ".join([f'"{col}" {infer_snowflake_type(dtype)}' for col, dtype in zip(df.columns, df.dtypes)])
    create_table_sql = f"CREATE OR REPLACE TABLE {schema}.{table_name} ({column_definitions})"
    try:

        # Execute the CREATE OR REPLACE TABLE statement
        cursor.execute(create_table_sql)
        # Bulk insert the DataFrame into Snowflake using write_pandas
        success, num_chunks, num_rows, output = write_pandas(conn, df, table_name= table_name, schema=schema)
        
        if success:
            print(f"FINANCE.{schema}.{table_name}")
        else:
            print(f"Failed to load data into {schema}.{table_name}")                    
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        cursor.close()
        conn.close()



def get_name_version(tableName):
    version = 0
    name = tableName
    if "_V" in name:
        temp = name.split("_V")
        name = temp[0]
        version = int(temp[1])
    elif "_v" in name:
        temp = name.split("_v")
        name = temp[0]
        version = int(temp[1])
    return (name, version)

