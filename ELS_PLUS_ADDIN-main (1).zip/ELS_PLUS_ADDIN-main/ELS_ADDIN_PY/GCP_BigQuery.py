import warnings
from google.cloud import bigquery
import openai
from google.oauth2 import service_account
import pandas as pd
import win32com.client as win32

# Suppress warnings
warnings.filterwarnings('ignore')

# Set default project
service_account_info = {
  "type": "service_account",
  "project_id": "lyrical-country-397623",
  "private_key_id": "26653c08607b502f95741c846830104efa7ae49c",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCaWY/4dGZ7OklG\nVIyIEPdEXZWY0BVwnnFlIhAJjrQ05qyx4mIi1bn0yFUz+ymO0qh8CkrKBFnE/Orl\n8zBfFtMN1cDnL0hQgcV7YDi1z3kt5Ho7W/An9MyEu4juzHV94/Yvbzb3Ez55LLwo\nD2ujl3rpmqU8s+DpY23U/Yt3cYE3AEC+JOyJifIcGfjL6pbHILW6jYHr3lGdcVxJ\nqXmYB1r9zKFn7LK8x79wzQObO0YC3Ooo+63JYi1YIdBu0dJj0YIgCpyIGM6EI+pJ\nh6YzVzDvxT7mws4ir8g50xSE4vpz7v/vJeZ+3PAm7mhOt/Q23bKXEHklt3pGsZDS\nX4SkJ2lNAgMBAAECggEAEHIwk/GbJdAtFJBXtPvRzPgHw5OQZUKMpJD/knUhIG3f\nwshzWnDZcoqSAYrmf7BUgXr7QxE5m3KzeLLz2X3uGRBIkJmKJAHfz+iNwlmL+Oba\nW07NhQRhclclHQSuFC7hAWbhPWxQgMrSdZZHCtROJWvz5UbpVRTiFAq7/IsckIaM\n2IP2fVDdZwvzkxbVvzQzyrisJ1YbCK6qsuees+B4cUknaEGs4rVYxn4//g0svTkY\noFvycpJFgrScUezvkTW5pqTnCeNwATyS90zKAFTAaHOGu3WucMsJBvi+WST5asbc\n/1CmDd6tVR0BuJ2D8vampcs+5sXGD4FZ6itcSoVvRQKBgQDZL/AYBde73k4R+I6O\ne+wA3AIc4VD398JY2lIV7wMC2Yg4BzEV3ngBvlrbnjbri9OnasG/YAfPM5ikt0tf\namTkr/JH6IHb4E5GJ2m/CrHXQiIZptUlFnDbS9kOu1XjV/Z5iyUa/xT4ZcKKWPPa\nFaIrGN9EC5WNWpa0Te7n2BSKfwKBgQC17uMTvlcCz1y5cEBStoyxGJkAE/bhz9qp\nfGF8Pb37Lf8+neEl2r81Lercfk/0dgQGFwiX6Radv9yb6jecbpSUeqtsiJ9rmEPo\ni9rEQOyXVW9DpEofJoOPe1kI6FWHci+Y5ctLNIbsujrnZUdKBwjzvCb9hi7Mpp5G\nFJQoAFMuMwKBgAnjjOMLIQ+Ex7k5wAPs0IoZel8mQzGHLmotRp+JCnIOxY0Hhsyg\nHIa3zBtD0OxYqYJt8fRswu5EQyb80Ym+pmljOXzcsUz5oZbAJKh2LDLI6BSS7BGM\nPAdAJNnu3bJERwyxsTbRdnr45yq1ciTz5zZfI4tNm7mb7lC3W7FivUyxAoGAUWNK\nxlxSBHnLW1GyFM6BZgBBAd3shdw8T7HK0o+0W5eaJeLvA8Y1345pELaZAh2Bc0/+\nkia97VgVUtKWii6V3U57PZRo7PMy/ecCuOTqclDP84yddA4AsMFXdTqqeGtGi7nR\nFhWrfl9ZVobiO2WmRZMYRjYu3XJ0P5mZJcPvci0CgYAWbNfhZFCPdkpSkdmo6+WR\npmjvhoxIf7MP1QmGxtc0GOh1I2QyFy6W5xj2VaeBEJXRhju4X99Ui7V/X0iL8ui2\n0iLPh3Sl0DpnyZBvKfZ5q6JCo7ojEQX6QhFejT9P9aMaIG7duAbE2ZwZoU0smOYI\n6lZZ+lqtMoa/ThbZpjD19w==\n-----END PRIVATE KEY-----\n",
  "client_email": "test-isai-service@lyrical-country-397623.iam.gserviceaccount.com",
  "client_id": "111104737233191547996",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/test-isai-service%40lyrical-country-397623.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}


credentials = service_account.Credentials.from_service_account_info(
    service_account_info,
    scopes=["https://www.googleapis.com/auth/cloud-platform"],
)

project_id = "lyrical-country-397623"
client = bigquery.Client(credentials=credentials, project=credentials.project_id)

# OpenAI API key
openai.api_key = "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"

def list_all_tables():
    dataset_list = list(client.list_datasets())
    table_list = []
    for dataset in dataset_list:
        tables = list(client.list_tables(dataset.dataset_id))
        for table in tables:
            table_list.append(f"{dataset.dataset_id}.{table.table_id}")
    return table_list

def fetch_data_from_table(table_name):
    sql = f"SELECT * FROM `{project_id}.{table_name}` LIMIT 1000"
    return client.query(sql).to_dataframe()

def ask_openai_with_context_for_table(question, table_name):
    df = fetch_data_from_table(table_name)
    context_list = [f"Table Name: {table_name}", f"Columns: {', '.join(df.columns)}"]

    numeric_cols = [col for col in df.columns if df[col].dtype in ['float64', 'int64']]
    for col in numeric_cols:
        context_list.append(f"For column '{col}', the average value is {df[col].mean():.2f}.")

    categorical_cols = [col for col in df.columns if df[col].dtype == 'object']
    for col in categorical_cols:
        top_values = df[col].value_counts().nlargest(5).index.tolist()
        context_list.append(f"For column '{col}', some frequent values are: {', '.join(top_values)}.")

    df_context = ' '.join(context_list)
    full_prompt = df_context + "\nQuestion: " + question + "\n\nWrite a BigQuery SQL to fetch the desired result:"

    response = openai.Completion.create(
      model="gpt-3.5-turbo-instruct",
      prompt=full_prompt,
      max_tokens=2048
    )
    return response.choices[0].text.strip()

def ask_openai_for_bigquery_function(query, table_name):
    context = f"You are working with a BigQuery table named '{table_name}'. Given the request, which BigQuery function or operation would be suitable?\n"
    full_prompt = context + query
    response = openai.Completion.create(
      model="text-davinci-003",
      prompt=full_prompt,
      max_tokens=200
    )
    return response.choices[0].text.strip()

# Dictionary to cache previous results
cache = {}

def get_openai_response_with_cache(question, table_name):
    # Check if the question is in cache
    if question in cache:
        return cache[question]

    # If not in cache, fetch the response from OpenAI
    response = ask_openai_with_context_for_table(question, table_name)
    if not response:
        response = ask_openai_for_bigquery_function(question, table_name)

    # Store the response in cache and return it
    cache[question] = response
    return response

def execute_and_save_to_excel(sql):
    """Execute the provided SQL query and save results to the active Excel sheet."""
    try:
        results = client.query(sql).to_dataframe()

        # Connect to the running instance of Excel
        excel = win32.gencache.EnsureDispatch('Excel.Application')
        workbook = excel.ActiveWorkbook
        sheet = workbook.ActiveSheet
        
        # Clear existing data
        sheet.Cells.Clear()

        # Write column headers
        columns = results.columns.tolist()
        for col_num, col_name in enumerate(columns, 1):
            sheet.Cells(1, col_num).Value = col_name

        # Write data rows
        for row_num, row in enumerate(results.itertuples(index=False), 2):
            for col_num, cell_value in enumerate(row, 1):
                sheet.Cells(row_num, col_num).Value = cell_value
        
        return "Results saved to the active Excel sheet."
    except Exception as e:
        return f"Error executing query: {e}"

def chat_box():
    tables = list_all_tables()
    print("Available tables:")
    for idx, table in enumerate(tables, 1):
        print(f"{idx}. {table}")

    choice = int(input("Select a table by number (or 'exit' to quit): ").strip())
    if choice < 1 or choice > len(tables):
        print("Invalid choice!")
        return
    selected_table = tables[choice - 1]

    while True:
        user_input = input("Enter your query or describe the operation you want to perform (or 'exit' to quit): ").strip()
        if user_input == 'exit':
            break
        else:
            response = get_openai_response_with_cache(user_input, selected_table)
            print(f"Generated SQL: {response}")

            # Now execute the SQL and save results to the active Excel sheet
            result_message = execute_and_save_to_excel(response)
            print(result_message)

# Start the chatbox
#chat_box()
