Imports System.Diagnostics
Imports System.IO
Imports System.Reflection
Imports System.Threading
Imports System.Windows.Forms
Imports Microsoft.Office.Tools.Ribbon
Imports Microsoft.Win32

Public Class Ribbon1

    Private userName As String = "test"
    Private userPassword As String = "pass"
    Private isSigned As Boolean = False

    WithEvents pythonProcess As New Process()
    Public Event Exited As EventHandler

    Public sheetColumnData As String = ""
    Public sheetColumns As Array
    Public sheetFieldTypes As Array
    Public sheetTableName As String = ""

    Dim ModelListBox As ListBox
    Dim QueryListBox As ListBox

    Private Sub Ribbon1_Load(ByVal sender As System.Object, ByVal e As RibbonUIEventArgs) Handles MyBase.Load
        Dim taskPane As Microsoft.Office.Tools.CustomTaskPane = Globals.ThisAddIn.myCustomTaskPane
        ModelListBox = Globals.ThisAddIn.myUserControl.ModelListBox
        QueryListBox = Globals.ThisAddIn.myUserControl.QueryListBox
        FnSign(False)
        PythonScriptRunner.pythonPath = GetPythonPath()
    End Sub
    Function FnSign(value As Boolean)
        BtnSignIn.Enabled = Not value
        BtnSignOut.Enabled = value
        BtnRun.Enabled = value
        BtnClear.Enabled = value
        BtnPrevious.Enabled = value
        BtnSave.Enabled = value
        BtnCommit.Enabled = value
        BtnShowPanel.Enabled = value
        BtnSetting.Enabled = value
        BtnShowPanel.Enabled = value
        Globals.ThisAddIn.myUserControl.BtnRefresh.Enabled = value
        isSigned = value
    End Function
    Private Sub BtnSignIn_Click(sender As Object, e As RibbonControlEventArgs) Handles BtnSignIn.Click
        Dim dialog As New LoginFrm()
        dialog.ShowDialog()
        If dialog.DialogResult = DialogResult.OK Then
            FnSign(True)
        End If
    End Sub
    Private Sub BtnSignOut_Click(sender As Object, e As RibbonControlEventArgs) Handles BtnSignOut.Click
        FnSign(False)
    End Sub

    Private Function GetPythonPath() As String
        Dim process As New Process()
        process.StartInfo.FileName = "where"
        process.StartInfo.Arguments = "python"
        process.StartInfo.UseShellExecute = False
        process.StartInfo.RedirectStandardOutput = True
        process.StartInfo.CreateNoWindow = True

        process.Start()
        Dim output As String = process.StandardOutput.ReadToEnd()
        process.WaitForExit()

        ' Display the path to python.exe
        If Not String.IsNullOrEmpty(output) Then
            Dim tempArray As Array = Split(output, "python.exe")
            output = tempArray(0) + "python.exe"
            Return output.Trim()
        Else
            Return ""
        End If
    End Function

    Private Sub BtnRun_Click(sender As Object, e As RibbonControlEventArgs) Handles BtnRun.Click
        If ModelListBox.SelectedIndex = -1 Then
            MessageBox.Show("Please select model", "Info")
            Return
        End If
        If QueryListBox.SelectedIndex = -1 Then
            MessageBox.Show("Please select query", "Info")
            Return
        End If

        Dim sOutput As String
        Dim tableArray As Array

        BtnRun.Enabled = False
        Dim tableName As String = ModelListBox.SelectedItem.ToString()
        Dim query As String = QueryListBox.SelectedItem.ToString()
        query = Replace(query, " ", "@")
        sOutput = PythonScriptRunner.Run_Python("google query " & tableName & " " & query)
        If sOutput.Contains("#") Then
            sheetColumnData = sOutput
            tableArray = Split(sOutput, "#")
            sheetColumns = Split(tableArray(0), ",")
            sheetFieldTypes = Split(tableArray(1), ",")
            sheetTableName = tableName
        End If
        BtnRun.Enabled = True
    End Sub

    Private Sub BtnPrevious_Click(sender As Object, e As RibbonControlEventArgs) Handles BtnPrevious.Click
        If Not sheetColumnData.Contains("#") Then
            MessageBox.Show("You have no previous data now", "Info")
            Return
        End If
        BtnPrevious.Enabled = False
        Dim sOutput As String
        sOutput = PythonScriptRunner.Run_Python("google previous " & sheetTableName)

        If sOutput.Contains("Success") Then
            Dim tempArray As Array = Split(sOutput, "#")
            sheetTableName = tempArray(1)
        End If
        BtnPrevious.Enabled = True
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As RibbonControlEventArgs) Handles BtnClear.Click
        BtnClear.Enabled = False
        Dim sOutput As String
        sOutput = PythonScriptRunner.Run_Python("google clear")
        BtnClear.Enabled = True
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As RibbonControlEventArgs) Handles BtnSave.Click
        If Not sheetColumnData.Contains("#") Then
            MessageBox.Show("You have no table data now", "Info")
            Return
        End If
        BtnSave.Enabled = False
        Dim sOutput As String
        sOutput = PythonScriptRunner.Run_Python("google save " & sheetTableName & " " & sheetColumnData)
        If sOutput.Contains("Success") Then
            Dim tempArray As Array = Split(sOutput, "#")
            sheetTableName = tempArray(1)
            MessageBox.Show("Successfully saved to BigQuery table", "Success")
        End If
        BtnSave.Enabled = True
    End Sub

    Private Sub BtnCommit_Click(sender As Object, e As RibbonControlEventArgs) Handles BtnCommit.Click
        If Not sheetColumnData.Contains("#") Then
            MessageBox.Show("You have no table data now", "Info")
            Return
        End If
        BtnCommit.Enabled = False
        Dim sOutput As String
        sOutput = PythonScriptRunner.Run_Python("google commit " & sheetTableName & " " & sheetColumnData)
        If sOutput.Contains("Success") Then
            Dim tempArray As Array = Split(sOutput, "#")
            sheetTableName = tempArray(1)
            MessageBox.Show("Successfully commited to BigQuery table", "Success")
        End If
        BtnCommit.Enabled = True
    End Sub

    Private Sub BtnShowPanel_Click(sender As Object, e As RibbonControlEventArgs)
        Dim taskPane As Microsoft.Office.Tools.CustomTaskPane = Globals.ThisAddIn.myCustomTaskPane
        taskPane.Visible = True
    End Sub

    Private Sub BtnSetting_Click(sender As Object, e As RibbonControlEventArgs) Handles BtnSetting.Click
        Dim dialog As New AuthSettingFrm()
        dialog.ShowDialog()
        If dialog.DialogResult = DialogResult.OK Then
            FnSign(True)
        End If
    End Sub

    Private Sub BtnShowPanel_Click_1(sender As Object, e As RibbonControlEventArgs) Handles BtnShowPanel.Click
        Dim taskPane As Microsoft.Office.Tools.CustomTaskPane = Globals.ThisAddIn.myCustomTaskPane
        taskPane.Visible = True
    End Sub
End Class
