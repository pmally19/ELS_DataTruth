﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ELS_PLUS_ADDIN
{
    public partial class new_dataset_name_dialog : Form
    {
        public string InputValue { get; private set; }

        public new_dataset_name_dialog()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.InputValue = this.inputTextBox.Text;
            // contains any special chracters
            if (!Utils.IsAllowedString(this.InputValue))
            {
                MessageBox.Show("The input contains invalid characters. Please remove any special characters.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            this.InputValue = Utils.SanitizeInput(this.InputValue);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.InputValue = this.inputTextBox.Text;
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
