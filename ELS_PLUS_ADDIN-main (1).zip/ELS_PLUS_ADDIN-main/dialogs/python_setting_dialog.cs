﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ELS_PLUS_ADDIN.dialogs
{
    public partial class python_setting_dialog : Form
    {
        public string testPyUrl = Utils.crrPyUrl;

        public python_setting_dialog()
        {
            InitializeComponent();
            this.testPy_textBox.Text = testPyUrl;
            this.pythonExe_textBox.Text = Utils.getPythonExeUrl();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (testPyUrl.Length > 0 && Utils.IsValidFileUrl(testPyUrl))
            {
                if (!testPyUrl.EndsWith("py"))
                {
                    MessageBox.Show("Only Select Python file, please");
                    return;
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            } else
            {
                MessageBox.Show("python file does not exist");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void python_setting_Load(object sender, EventArgs e)
        {

        }

        private void testPy_textBox_TextChanged(object sender, EventArgs e)
        {
            testPyUrl = this.testPy_textBox.Text;
        }
    }
}
