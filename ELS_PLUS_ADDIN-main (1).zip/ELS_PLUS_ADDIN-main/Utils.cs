﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace ELS_PLUS_ADDIN
{
    public partial class Utils
    {
        public static string pythonExeUrl;
        public static string gcpPyUrl = "C:\\ELS_ADDIN_PY\\run-gcp.py";
        public static string snowflakePyUrl = "C:\\ELS_ADDIN_PY\\run-snowflake.py";
        public static string crrPyUrl = gcpPyUrl;

        private static HashSet<char> allowedChars = new HashSet<char>("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890 _".ToCharArray());
        // check string contains any other special characters that can't be used in SQL query.
        public static bool IsAllowedString(string str)
        {
            if (str.Any(c => !allowedChars.Contains(c)))
            {
                return false;
            }

            return true;
        }
        
        public static string SanitizeInput(string input)
        {
            // Trim the input to remove leading and trailing whitespaces
            string trimmedInput = input.Trim();

            // Replace all spaces with underscores
            return trimmedInput.Replace(" ", "_");
        }

        // remove all blank rows and cols from origin array
        public static string[,] removeBlankRowCols(string[,] origin, bool isZeroBased)
        {
            if (origin == null)
                return new string[0, 0];

            int rowCount = origin.GetLength(0);
            int colCount = origin.GetLength(1);

            if (isZeroBased == false)
            {
                string[,] temp = new string[rowCount, colCount];
                for (int i = 0 ; i < rowCount; i++)
                {
                    for (int j = 0; j < colCount; j++)
                    {
                        temp[i, j] = origin[i, j];
                    }
                }

                origin = new string[rowCount, colCount];
                for (int i = 0; i < rowCount; i++)
                {
                    for (int j = 0; j < colCount; j++)
                    {
                        origin[i, j] = temp[i, j];
                    }
                }

            }

            int realRowCount = 0, realColCount = 0;
            // optimize rows
            string[,] rowOptimizedArray = new string[rowCount, colCount];
            for(int i = 0; i < rowCount; i++) 
            {
                int j = 0;
                for(; j < colCount; j++)
                {
                    if (origin[i, j] != null)
                        break;
                }

                if (j != colCount) // this row is used, so we need to copy this
                {
                    for(j = 0; j < colCount; j ++)
                    {
                        rowOptimizedArray[realRowCount, j] = origin[i, j];
                    }
                    realRowCount++;
                }

            }


            string[,] colOptimizedArray = new string[realRowCount, colCount];
            for (int i = 0; i < colCount; i++)
            {
                int j = 0;
                for (; j < realRowCount; j++)
                {
                    if (rowOptimizedArray[j, i] != null)
                        break;
                }

                if (j != realRowCount) // this col is used, so we need to copy this
                {
                    for (j = 0; j < realRowCount; j ++)
                    {
                        colOptimizedArray[j, realColCount] = rowOptimizedArray[j, i];
                    }
                    realColCount ++;
                }
            }


            // finalized data
            string[, ] result = new string[realRowCount, realColCount];
            for (int i = 0; i < realRowCount; i++)
            {
                for (int j = 0; j < realColCount; j++)
                {
                    result[i, j] = colOptimizedArray[i, j];
                }
            }

            return result;

        }

        public static string getPythonExeUrl()
        {
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = "where";
            start.Arguments = "python";
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            start.CreateNoWindow = true;
            string result = "";
            using (Process process = Process.Start(start))
            {
                using (StreamReader reader = process.StandardOutput)
                {
                    result = reader.ReadToEnd();
                    int i = result.IndexOf("python.exe");
                    int len = result.Length;
                    string path = "";
                    if (i >= 0)
                    {
                        path = result.Substring(0, i + 10);
                    }
                    else
                    {
                        MessageBox.Show("Please install python v3.12");
                        return "";
                    }
                    return path;
                }
            }
        }

        /// <summary>
        /// Checks if the given file URL is valid and the file exists.
        /// </summary>
        /// <param name="fileUrl">The file URL to check.</param>
        /// <returns>True if the file URL is valid and the file exists; otherwise, false.</returns>
        public static bool IsValidFileUrl(string fileUrl)
        {
            try
            {
                // Convert the URL to a URI object
                var uri = new Uri(fileUrl);

                // Check if the URI scheme is file
                if (uri.Scheme != Uri.UriSchemeFile)
                {
                    return false;
                }

                // Get the local path from the URI
                string filePath = uri.LocalPath;

                // Check if the file exists on the local file system
                return File.Exists(filePath);
            }
            catch (Exception ex) when (ex is UriFormatException || ex is InvalidOperationException)
            {
                // If exception occurs during URI parsing or converting to local path, 
                // the URL is invalid
                return false;
            }
        }


        public static string getColumnTypeFromColumnData(Object[] columnData)
        {
            String resultType = "";

            for(int i = 0; i < columnData.Length; i++)
            {
                if (columnData[i] == null)
                    continue;

                String type = CheckStringType(columnData[i].ToString());
                if (resultType == "")
                    resultType = type;
                else if (resultType == "INT" && type == "FLOAT")
                    resultType = type;
                else if (type == "STRING")
                    resultType = type;
            }

            if (resultType == "")
                return "STRING";

            return resultType;
        }

        public static (String[], String[]) getColumnNamesAndTypes(Object[,] dataArray)
        {
            int rowCount = dataArray.GetLength(0);
            int colCount = dataArray.GetLength(1);
            
            String[] columnNames = new string[colCount];
            String[] columnTypes = new string[colCount];


            for(int i = 0; i < colCount; i ++)
            {
                columnNames[i] = dataArray[0, i].ToString();

                Object[] columnData = new Object[rowCount - 1];
                for(int j = 1; j < rowCount; j ++)
                {
                    columnData[j - 1] = dataArray[j, i];
                }

                columnTypes[i] = getColumnTypeFromColumnData(columnData);
            } 

            return (columnNames, columnTypes);
        }

        public static string[,] getStringArrayFromSelection()
        {
            Excel.Range selection = Globals.ThisAddIn.Application.Selection as Excel.Range;
            List<string> dateAsStringList = new List<string>();

            if (selection != null)
            {
                foreach (Excel.Range item in selection.Cells)
                {
                    // Using cell.Text to get the formatted text value of each cell
                    string cellText = item.Text.ToString();
                    dateAsStringList.Add(cellText);
                }
            }

            // Convert the List to an array.
            string[] dateAsStringArray = dateAsStringList.ToArray();
            string[,] stringArray = null;

            // Make sure the selection is not null and that it is a range.
            if (Globals.ThisAddIn.Application.Selection != null)
            {
                // Get the values from the selected range.
                object[,] valuesArray = Globals.ThisAddIn.Application.Selection.Value2;

                if (valuesArray != null)
                {
                    int rowCount = valuesArray.GetLength(0);
                    int colCount = valuesArray.GetLength(1);
                    stringArray = new string[rowCount, colCount];

                    // Convert each value in the range to a string.
                    for (int row = 0; row < rowCount; row++)
                    {
                        for (int col = 0; col < colCount; col++)
                        {
                            stringArray[row, col] = dateAsStringArray[row * colCount + col];
                        }
                    }
                }

                // Now stringArray contains strings that represent the text in each cell of the selection.
                // You can use stringArray as needed.
            }

            return stringArray;
        }

        public static String CheckStringType(string input)
        {
            // Check for integer
            if (int.TryParse(input, out int intValue))
            {
                return "INTEGER";
            }
            // Check for float
            else if (float.TryParse(input, out float floatValue))
            {
                return "FLOAT";
            }
            // It's a string
            else
            {
                return "STRING";
            }

        }


    }
}
