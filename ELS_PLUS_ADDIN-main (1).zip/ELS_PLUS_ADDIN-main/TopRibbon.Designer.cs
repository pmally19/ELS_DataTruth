﻿namespace ELS_PLUS_ADDIN
{
    partial class TopRibbon : Microsoft.Office.Tools.Ribbon.RibbonBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        public TopRibbon()
            : base(Globals.Factory.GetRibbonFactory())
        {
            InitializeComponent();
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TopRibbon));
            this.tab1 = this.Factory.CreateRibbonTab();
            this.group4 = this.Factory.CreateRibbonGroup();
            this.toggleButton2 = this.Factory.CreateRibbonToggleButton();
            this.toggleButton1 = this.Factory.CreateRibbonToggleButton();
            this.group1 = this.Factory.CreateRibbonGroup();
            this.btnSetting = this.Factory.CreateRibbonButton();
            this.showPane_rbtn = this.Factory.CreateRibbonButton();
            this.group2 = this.Factory.CreateRibbonGroup();
            this.getData_rbtn = this.Factory.CreateRibbonButton();
            this.clear_rbtn = this.Factory.CreateRibbonButton();
            this.prev_rbtn = this.Factory.CreateRibbonButton();
            this.save_rbtn = this.Factory.CreateRibbonButton();
            this.commit_rbtn = this.Factory.CreateRibbonButton();
            this.group3 = this.Factory.CreateRibbonGroup();
            this.btn_create_new_dataset = this.Factory.CreateRibbonButton();
            this.btn_save_dataset = this.Factory.CreateRibbonButton();
            this.btn_show_dataset = this.Factory.CreateRibbonButton();
            this.tab1.SuspendLayout();
            this.group4.SuspendLayout();
            this.group1.SuspendLayout();
            this.group2.SuspendLayout();
            this.group3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab1
            // 
            this.tab1.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office;
            this.tab1.Groups.Add(this.group4);
            this.tab1.Groups.Add(this.group1);
            this.tab1.Groups.Add(this.group2);
            this.tab1.Groups.Add(this.group3);
            this.tab1.Label = "ELS+";
            this.tab1.Name = "tab1";
            // 
            // group4
            // 
            this.group4.Items.Add(this.toggleButton2);
            this.group4.Items.Add(this.toggleButton1);
            this.group4.Label = "Platform";
            this.group4.Name = "group4";
            // 
            // toggleButton2
            // 
            this.toggleButton2.Image = ((System.Drawing.Image)(resources.GetObject("toggleButton2.Image")));
            this.toggleButton2.Label = "Snowflake";
            this.toggleButton2.Name = "toggleButton2";
            this.toggleButton2.ShowImage = true;
            this.toggleButton2.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.toggleButton2_Click);
            // 
            // toggleButton1
            // 
            this.toggleButton1.Checked = true;
            this.toggleButton1.Image = ((System.Drawing.Image)(resources.GetObject("toggleButton1.Image")));
            this.toggleButton1.Label = "GCP";
            this.toggleButton1.Name = "toggleButton1";
            this.toggleButton1.ShowImage = true;
            this.toggleButton1.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.toggleButton1_Click);
            // 
            // group1
            // 
            this.group1.Items.Add(this.btnSetting);
            this.group1.Items.Add(this.showPane_rbtn);
            this.group1.Label = "Setting";
            this.group1.Name = "group1";
            // 
            // btnSetting
            // 
            this.btnSetting.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.btnSetting.Label = "Python Setting";
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.OfficeImageId = "MoveToFolderFileMenu";
            this.btnSetting.ShowImage = true;
            this.btnSetting.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btnSetting_Click);
            // 
            // showPane_rbtn
            // 
            this.showPane_rbtn.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.showPane_rbtn.Label = "Show taskpane";
            this.showPane_rbtn.Name = "showPane_rbtn";
            this.showPane_rbtn.OfficeImageId = "VisibilityVisible";
            this.showPane_rbtn.ShowImage = true;
            this.showPane_rbtn.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.showPane_rbtn_Click);
            // 
            // group2
            // 
            this.group2.Items.Add(this.getData_rbtn);
            this.group2.Items.Add(this.clear_rbtn);
            this.group2.Items.Add(this.prev_rbtn);
            this.group2.Items.Add(this.save_rbtn);
            this.group2.Items.Add(this.commit_rbtn);
            this.group2.Label = "Action";
            this.group2.Name = "group2";
            // 
            // getData_rbtn
            // 
            this.getData_rbtn.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.getData_rbtn.Enabled = false;
            this.getData_rbtn.Label = "GetData";
            this.getData_rbtn.Name = "getData_rbtn";
            this.getData_rbtn.OfficeImageId = "RssDownloadContent";
            this.getData_rbtn.ShowImage = true;
            this.getData_rbtn.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.getData_rbtn_Click);
            // 
            // clear_rbtn
            // 
            this.clear_rbtn.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.clear_rbtn.Label = "Clear";
            this.clear_rbtn.Name = "clear_rbtn";
            this.clear_rbtn.OfficeImageId = "Clear";
            this.clear_rbtn.ShowImage = true;
            this.clear_rbtn.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.clear_rbtn_Click);
            // 
            // prev_rbtn
            // 
            this.prev_rbtn.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.prev_rbtn.Enabled = false;
            this.prev_rbtn.Label = "Previous";
            this.prev_rbtn.Name = "prev_rbtn";
            this.prev_rbtn.OfficeImageId = "ReviewPreviousChange";
            this.prev_rbtn.ShowImage = true;
            this.prev_rbtn.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.prev_rbtn_Click);
            // 
            // save_rbtn
            // 
            this.save_rbtn.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.save_rbtn.Label = "Save";
            this.save_rbtn.Name = "save_rbtn";
            this.save_rbtn.OfficeImageId = "FileSave";
            this.save_rbtn.ShowImage = true;
            this.save_rbtn.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.save_rbtn_Click);
            // 
            // commit_rbtn
            // 
            this.commit_rbtn.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.commit_rbtn.Label = "Commit";
            this.commit_rbtn.Name = "commit_rbtn";
            this.commit_rbtn.OfficeImageId = "GroupChangesTracking";
            this.commit_rbtn.ShowImage = true;
            this.commit_rbtn.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.commit_rbtn_Click);
            // 
            // group3
            // 
            this.group3.Items.Add(this.btn_create_new_dataset);
            this.group3.Items.Add(this.btn_save_dataset);
            this.group3.Items.Add(this.btn_show_dataset);
            this.group3.Label = "Dataset";
            this.group3.Name = "group3";
            // 
            // btn_create_new_dataset
            // 
            this.btn_create_new_dataset.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.btn_create_new_dataset.Label = "Create Dataset";
            this.btn_create_new_dataset.Name = "btn_create_new_dataset";
            this.btn_create_new_dataset.OfficeImageId = "SlideNew";
            this.btn_create_new_dataset.ShowImage = true;
            this.btn_create_new_dataset.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btn_create_new_dataset_Click);
            // 
            // btn_save_dataset
            // 
            this.btn_save_dataset.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.btn_save_dataset.Enabled = false;
            this.btn_save_dataset.Label = "Save Dataset";
            this.btn_save_dataset.Name = "btn_save_dataset";
            this.btn_save_dataset.OfficeImageId = "SaveSelectionToQuickTablesGallery";
            this.btn_save_dataset.ShowImage = true;
            this.btn_save_dataset.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btn_save_dataset_Click);
            // 
            // btn_show_dataset
            // 
            this.btn_show_dataset.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge;
            this.btn_show_dataset.Label = "Show Dataset";
            this.btn_show_dataset.Name = "btn_show_dataset";
            this.btn_show_dataset.OfficeImageId = "SubdocumentOpen";
            this.btn_show_dataset.ShowImage = true;
            this.btn_show_dataset.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btn_show_dataset_Click);
            // 
            // TopRibbon
            // 
            this.Name = "TopRibbon";
            this.RibbonType = "Microsoft.Excel.Workbook";
            this.Tabs.Add(this.tab1);
            this.Load += new Microsoft.Office.Tools.Ribbon.RibbonUIEventHandler(this.Ribbon1_Load);
            this.tab1.ResumeLayout(false);
            this.tab1.PerformLayout();
            this.group4.ResumeLayout(false);
            this.group4.PerformLayout();
            this.group1.ResumeLayout(false);
            this.group1.PerformLayout();
            this.group2.ResumeLayout(false);
            this.group2.PerformLayout();
            this.group3.ResumeLayout(false);
            this.group3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal Microsoft.Office.Tools.Ribbon.RibbonTab tab1;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group2;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton getData_rbtn;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton prev_rbtn;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton clear_rbtn;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton save_rbtn;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton commit_rbtn;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton showPane_rbtn;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group3;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btn_create_new_dataset;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btn_save_dataset;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btn_show_dataset;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group1;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btnSetting;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group4;
        internal Microsoft.Office.Tools.Ribbon.RibbonToggleButton toggleButton1;
        internal Microsoft.Office.Tools.Ribbon.RibbonToggleButton toggleButton2;
    }

    partial class ThisRibbonCollection
    {
        internal TopRibbon Ribbon1
        {
            get { return this.GetRibbon<TopRibbon>(); }
        }
    }
}
