﻿using ELS_PLUS_ADDIN.dialogs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace ELS_PLUS_ADDIN
{
    public partial class UserControl : System.Windows.Forms.UserControl
    {
        public Dictionary<string, List<string>> schemas = new Dictionary<string, List<string>>();
        private Process runningProcess = null;

        public UserControl()
        {
            InitializeComponent();
            initiateControls();            
        }

        public void UserControl_Load(object sender, EventArgs e)
        {

        }
        public void initiateControls()
        {
            // initialize python urls
            Utils.pythonExeUrl = Utils.getPythonExeUrl();

            schema_combo.Items.Clear();
            schema_combo.Text = "";

            progressBar1.Visible = false;
            getColumnData_btn.Enabled = false;

            tableList_listBox.Items.Clear();
            column_listBox.Items.Clear();
            selectedTableName.Text = "";

            getData_btn.Enabled = false;
            clear_btn.Enabled = true;

            previous_btn.Enabled = false;
            save_btn.Enabled = false;
            commit_btn.Enabled = false;

            run_btn.Enabled = false;
            QueryClearBtn.Enabled = false;
            QueryStopBtn.Enabled = false;

            Globals.Ribbons.Ribbon1.getData_rbtn.Enabled = false;
            Globals.Ribbons.Ribbon1.prev_rbtn.Enabled = false;
        }

        public void run_cmd(string args)
        {
            String pythonExeUrl = Utils.pythonExeUrl;
            String testPyUrl = Utils.crrPyUrl;

            progressBar1.Invoke((MethodInvoker)(() =>
            {
                progressBar1.Visible = true;
            }));

            try
            {
                args = args.Trim();
                ProcessStartInfo start = new ProcessStartInfo();
                start.FileName = pythonExeUrl;
                start.Arguments = string.Format("{0} {1}", testPyUrl, args);
                start.UseShellExecute = false;
                start.RedirectStandardOutput = true;
                start.CreateNoWindow = true;
                string result = "";
                using (runningProcess = Process.Start(start))
                {
                    using (StreamReader reader = runningProcess.StandardOutput)
                    {
                        result = reader.ReadToEnd();
                        if (result.StartsWith("Error"))
                        {
                            MessageBox.Show($"{result}");

                            return;
                        }
                        else if (result == "")
                        {
                            MessageBox.Show("Python execution error: \nStep 1: Ensure that Python 3.12 or a later version is installed correctly.\r\n\r\n Step2: Ensure that pip install -r requirements.txt \r\n\r\nStep 3: Verify that the file lyrical-country-***.json is located in the C:/test directory. \n check another issues");
                        }
                        else if (args == "google refresh" || args == "snowflake refresh")
                        {

                            result.Trim();
                            string[] tables = result.Split('#');

                            schemas.Clear();
                            for (int i = 1; i < tables.Length; i++)
                            {
                                string[] table = tables[i].Split('.');
                                if (table.Length == 2)
                                {
                                    if (!schemas.ContainsKey(table[0])) schemas.Add(table[0], new List<string>());
                                    schemas[table[0]].Add(table[1]);
                                }
                                else if (table.Length == 3)
                                {
                                    if (!schemas.ContainsKey(table[0] + "." + table[1])) schemas.Add(table[0] + "." + table[1], new List<string>());
                                    schemas[table[0] + "." + table[1]].Add(table[2]);
                                }

                            }
                            // Iterating over the dictionary
                            schema_combo.Invoke((MethodInvoker)(() =>
                            {

                                foreach (KeyValuePair<string, List<string>> sce in schemas)
                                {
                                    schema_combo.Items.Add(sce.Key);
                                }
                                schema_combo.SelectedItem = 0;

                            }));

                        }
                        else if (args.StartsWith("google columns") || args.StartsWith("snowflake columns"))
                        {
                            string[] columns = result.Split('#');

                            for (int i = 1; i < columns.Length; i++)
                            {
                                column_listBox.Invoke((MethodInvoker)(() =>
                                {
                                    column_listBox.Items.Add(columns[i]);
                                    getColumnData_btn.Enabled = true;
                                }));
                            }
                        }
                        else if (args.StartsWith("google tabledata") || args.StartsWith("snowflake tabledata"))
                        {
                            string[] splitData = result.Trim().Split('#');
                            tableList_listBox.Invoke((MethodInvoker)(() =>
                            {
                                getDataLoading(false);
                                getData_btn.Enabled = true;
                                Globals.Ribbons.Ribbon1.getData_rbtn.Enabled = true;
                            }));
                        }
                        else if (args.StartsWith("google gpt") || args.StartsWith("snowflake gpt"))
                        {
                            progressBar1.Invoke((MethodInvoker)(() =>
                            {
                                QueryStopBtn.Enabled = false;
                                run_btn.Enabled = true;
                            }));
                        }
                        else if (args.StartsWith("google prestage-create") || args.StartsWith("snowflake prestage-create"))
                        {
                            selectedTableName.Invoke((MethodInvoker)(() =>
                            {
                                string table_name = result.Split('.')[2];
                                selectedTableName.Text = table_name.Trim();
                                Globals.Ribbons.Ribbon1.btn_save_dataset.Enabled = true;
                            }));

                        }
                        else if (args.StartsWith("google prestage-save") || args.StartsWith("snowflake prestage-save"))
                        {
                            //Utils.currentPrestageTableId = result;
                            //Globals.Ribbons.Ribbon1.btn_save_dataset.Enabled = true;
                        }
                        else if (args.StartsWith("google prestage_show_data") || args.StartsWith("snowflake prestage_show_data"))
                        {
                            Globals.Ribbons.Ribbon1.btn_save_dataset.Enabled = true;

                            tableList_listBox.Invoke((MethodInvoker)(() =>
                            {
                                clear_btn.Enabled = true;
                            }));
                        }

                        else if (args.StartsWith("google save") || args.StartsWith("snowflake save"))
                        {
                            tableList_listBox.Invoke((MethodInvoker)(() =>
                            {
                                result = result.Trim();

                                selectedTableName.Text = result.Split('.')[2];
                                previous_btn.Enabled = true;
                                Globals.Ribbons.Ribbon1.prev_rbtn.Enabled = true;
                                MessageBox.Show($"Successfully saved to table: {selectedTableName.Text}");
                            }));
                        }
                        else if (args.StartsWith("google previous") || args.StartsWith("snowflake previous"))
                        {
                            tableList_listBox.Invoke((MethodInvoker)(() =>
                            {
                                string table_name = result.Trim().Split('.')[1];

                                selectedTableName.Text = table_name;

                                MessageBox.Show($"Previous table: {table_name}");
                            }));

                        }
                        else if (args.StartsWith("google commit") || args.StartsWith("snowflake commit"))
                        {
                            tableList_listBox.Invoke((MethodInvoker)(() =>
                            {
                                result = result.Trim();
                                //tableList_listBox.Items.Add(table_name);
                                //tableList_listBox.SelectedIndex = tableList_listBox.Items.Count - 1;
                                //selectedTabe_textbox.Text = table_name;

                                clearTableContents();
                                MessageBox.Show($"Successfully commited to table: {result.Split('.')[1] + "." + result.Split('.')[2]}");
                            }));
                        }
                        else
                        {
                            MessageBox.Show($"Error: {result}");
                            progressBar1.Invoke((MethodInvoker)(() =>
                            {
                                progressBar1.Visible = false;
                            }));
                            return;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show($"Error:{e.Message}" );
                
                
            }
            finally
            {
                progressBar1.Invoke((MethodInvoker)(() =>
                {
                    progressBar1.Visible = false;
                }));
                runningProcess = null;
            }
            
        }
        public void stopProcess()
        {
            if (runningProcess != null && !runningProcess.HasExited)
            {
                runningProcess.Kill();  // Forcefully stops the process
                runningProcess.Dispose();
                runningProcess = null;
                QueryStopBtn.Enabled = false;
                run_btn.Enabled = true;
            }
        }
        public void tablelist_refresh()
        {
            initiateControls();
            if (Globals.Ribbons.Ribbon1.toggleButton1.Checked) Task.Run(() => run_cmd("google refresh"));
            else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked) Task.Run(() => run_cmd("snowflake refresh"));
        }


        public void tableList_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            getColumnData_btn.Enabled = true;
            column_listBox.Items.Clear();
            clearTableContents();
            previous_btn.Enabled = true;
            save_btn.Enabled = true;
            commit_btn.Enabled = true;
            run_btn.Enabled = true;
            QueryClearBtn.Enabled = true;
            selectedTableName.Text = tableList_listBox.SelectedItem.ToString();
            
        }

        public void getDataLoading(bool b)
        {
            //signOut_btn.Enabled = !b;
            column_listBox.Enabled = !b;
            getColumnData_btn.Enabled = !b;
            getData_btn.Enabled = false;

        }
        public void showTable()
        {
            showPrestageDatasetTable();
        }
        public void showPrestageDatasetTable()
        {
            string schema_name = schema_combo.SelectedItem.ToString();
            string table_name = selectedTableName.Text;
            if (schema_name.Length == 0 || table_name.Length ==0)
            {
                MessageBox.Show("Please select shcema and table");
                return;
            }

            progressBar1.Visible = true;
            if (Globals.Ribbons.Ribbon1.toggleButton1.Checked) Task.Run(() => run_cmd($"google prestage_show_data {schema_name}.{table_name}"));
            else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked) Task.Run(() => run_cmd($"snowflake prestage_show_data {schema_name}.{table_name}"));
        }

        public void getData_ctn_Click(object sender, EventArgs e)
        {
            string schema_name = schema_combo.SelectedItem.ToString();
            string table_name = selectedTableName.Text;
            if (schema_name.Length == 0 || table_name.Length == 0)
            {
                MessageBox.Show("Please select shcema and table");
                return;
            }
            List<string> columnsId = column_listBox.CheckedItems.Cast<string>().ToList();
            string columns = "";
            string keyword1 = "TOTALPRICE";
            string keyword2 = "ACCTBAL";
            if (columnsId.Count > 0)
            {
                progressBar1.Visible = true;
                getData_btn.Enabled = false;
                Globals.Ribbons.Ribbon1.getData_rbtn.Enabled = false;
                getDataLoading(true);
                int len = columnsId.Count;
                int k = 0;
                foreach (var column in columnsId)
                {
                    columns += column;
                    k++;
                    if (k != len) columns += "#";

                }

                if (Globals.Ribbons.Ribbon1.toggleButton1.Checked)
                {
                    string tableId = schema_name + "."  +table_name;
                    Task.Run(() => run_cmd($"google tabledata {tableId} {columns}"));
                }
                else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked)
                {
                    string tableId = schema_name + "." + table_name;
                    Task.Run(() => run_cmd($"snowflake tabledata {tableId} {columns}"));
                }

            }
            else
            {
                MessageBox.Show("Please select the columns.");
            }
            
        }

        public void getColumnData_btn_Click(object sender, EventArgs e)
        {
            string schema_name = schema_combo.SelectedItem.ToString();
            string table_name = selectedTableName.Text;
            if (schema_name.Length == 0 || table_name.Length == 0)
            {
                MessageBox.Show("Please select shcema and table");
                return;
            }
            progressBar1.Visible = true;
            getColumnData_btn.Enabled = false;

            if (Globals.Ribbons.Ribbon1.toggleButton1.Checked) Task.Run(() => run_cmd($"google columns {schema_name + "." + table_name}"));
            else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked) Task.Run(() => run_cmd($"snowflake columns {schema_name + "." + table_name}"));

        }

        public void column_listBox_ItemCheck(object sender, ItemCheckEventArgs e)
        {

        }


        public void column_listBox_SelectedValueChanged(object sender, EventArgs e)
        {
            if (column_listBox.CheckedItems.Count > 0)
            {
                getData_btn.Enabled = true;
                Globals.Ribbons.Ribbon1.getData_rbtn.Enabled = true;
            }
            else
            {
                getData_btn.Enabled = false;
                Globals.Ribbons.Ribbon1.getData_rbtn.Enabled = false;
            }
        }

        public void testPy_textBox_TextChanged(object sender, EventArgs e)
        {
            //testPyUrl = testPy_textBox.Text;
        }

        public void pythonExe_textBox_TextChanged(object sender, EventArgs e)
        {
            //pythonExeUrl = pythonExe_textBox.Text;
        }
        public (string, int) GetNameAndVersion(string input)
        {
            // Define a regex pattern to match "_v" followed by one or more digits
            string pattern = @"_V(\d+)$";
            Match match = Regex.Match(input, pattern, RegexOptions.IgnoreCase);

            if (match.Success)
            {
                // Extract the version number from the matched group
                int version = int.Parse(match.Groups[1].Value);
                // Get the part of the string without the version number
                string nameWithoutVersion = input.Substring(0, match.Index);
                return (nameWithoutVersion, version);
            }
            else
            {
                // Return the original string and -1 if no version is found
                return (input, -1);
            }
        }

        public void save_btn_Click(object sender, EventArgs e)
        {
   
            string tb_name;

            tb_name = selectedTableName.Text.ToUpper();
            (string nameWithoutVersion, int version) = GetNameAndVersion(tb_name);
            if (version < 0) version = 0;
            else version++;
            tb_name = nameWithoutVersion + "_v" + version;
            if (Globals.Ribbons.Ribbon1.toggleButton1.Checked) Task.Run(() => run_cmd($"google save {tb_name.Replace('.', '_')}"));
            else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked) Task.Run(() => run_cmd($"snowflake save {tb_name.Replace('.', '_')}"));

            progressBar1.Visible = true;
        }


        public void clearTableContents()
        {
            Globals.ThisAddIn.Application.ActiveSheet.Cells.ClearContents();
            //clear_btn.Enabled = false;
            //progressBar1.Visible = true;
            //Task.Run(() => run_cmd(pythonExeUrl, testPyUrl, $"google clear"));
        }
        public void clear_btn_Click(object sender, EventArgs e)
        {
            
            clearTableContents();
        }

        public void previous_btn_Click(object sender, EventArgs e)
        {
            string table_name = selectedTableName.Text;

            if (table_name == "")
            {
                MessageBox.Show("You should select table.");
                return;
            }
            previous_btn.Enabled = false;
            progressBar1.Visible = true;
            if (Globals.Ribbons.Ribbon1.toggleButton1.Checked) Task.Run(() => run_cmd($"google previous {table_name}"));
            else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked) Task.Run(() => run_cmd($"snowflake previous {table_name}"));


        }

        public void commit_btn_Click(object sender, EventArgs e)
        {
            string tb_name = selectedTableName.Text;

            (string nameWithoutVersion, int version) = GetNameAndVersion(tb_name);
            tb_name = nameWithoutVersion;
            if (Globals.Ribbons.Ribbon1.toggleButton1.Checked) Task.Run(() => run_cmd($"google commit {tb_name.Replace('.', '_')}"));
            else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked) Task.Run(() => run_cmd($"snowflake commit {tb_name.Replace('.', '_')}"));

            progressBar1.Visible = true;
        }


        public void run_btn_Click(object sender, EventArgs e)
        {
            string query = query_textbox.ToString();
            string table_name = schema_combo.SelectedItem.ToString() + "." + tableList_listBox.SelectedItem.ToString();

            progressBar1.Visible = true;
            run_btn.Enabled = false;
            QueryStopBtn.Enabled = true;
            if (Globals.Ribbons.Ribbon1.toggleButton1.Checked) Task.Run(() => run_cmd($"google gpt {table_name} \"{query}\""));
            else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked) Task.Run(() => run_cmd($"snowflake gpt {table_name} \"{query}\""));
        }

        public void onSavePrestageDataset()
        {
            string schema_name = schema_combo.SelectedItem.ToString();
            string table_name = selectedTableName.Text;
            if (schema_name.Length == 0 || table_name.Length == 0)
            {
                MessageBox.Show("Please select shcema and table");
                return;
            }
            if (Globals.Ribbons.Ribbon1.toggleButton1.Checked) Task.Run(() => run_cmd($"google prestage-save {schema_name} {table_name}"));
            else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked) Task.Run(() => run_cmd($"snowflake prestage-save {schema_name} {table_name}"));
        }


        public void onCreatePrestageDataset()
        {
            string schema_name = schema_combo.SelectedItem.ToString();
            if (schema_name.Length == 0)
            {
                MessageBox.Show("Please select schema");
                return;
            }
            // show dataset name dialog
            using (new_dataset_name_dialog dialog = new new_dataset_name_dialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    // Use the InputValue from the dialog after it has been closed with 'OK'
                    string tableName = dialog.InputValue;
                                                         
                    if (Globals.Ribbons.Ribbon1.toggleButton1.Checked) Task.Run(() => run_cmd($"google prestage-create {schema_name} {tableName}"));
                    else if (Globals.Ribbons.Ribbon1.toggleButton2.Checked) Task.Run(() => run_cmd($"snowflake prestage-create {schema_name} {tableName}"));
                }
            }
        }

        private void btnRefreshTableList_Click(object sender, EventArgs e)
        {
            tablelist_refresh();
        }

        private void btn_check_uncheck_all_Click(object sender, EventArgs e)
        {
            bool allChecked = true;
            for (int i = 0; i < column_listBox.Items.Count; i++)
            {
                if (!column_listBox.GetItemChecked(i))
                {
                    allChecked = false;
                    break;
                }
            }


            if (allChecked)
            {
                for (int i = 0; i < column_listBox.Items.Count; i++)
                {
                    column_listBox.SetItemChecked(i, false);
                }
            }
            else
            {
                for (int i = 0; i < column_listBox.Items.Count; i++)
                {
                    column_listBox.SetItemChecked(i, true);
                }
            }
        }

        private void querylist_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void schema_combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (schema_combo.Items.Count > 0)
            {                
                tableList_listBox.Items.Clear();
                foreach (string s in schemas[schema_combo.SelectedItem.ToString()])
                {
                    tableList_listBox.Items.Add(s);
                }
            }
        }

        private void QueryClearBtn_Click(object sender, EventArgs e)
        {
            query_textbox.Clear();
        }

        private void QueryStopBtn_Click(object sender, EventArgs e)
        {
            stopProcess();
        }

    }
}
