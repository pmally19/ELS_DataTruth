﻿namespace ELS_PLUS_ADDIN
{

    partial class UserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tableList_listBox = new System.Windows.Forms.ListBox();
            this.btnRefreshTableList = new System.Windows.Forms.Button();
            this.getColumnData_btn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_check_uncheck_all = new System.Windows.Forms.Button();
            this.column_listBox = new System.Windows.Forms.CheckedListBox();
            this.getData_btn = new System.Windows.Forms.Button();
            this.clear_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.previous_btn = new System.Windows.Forms.Button();
            this.commit_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.QueryClearBtn = new System.Windows.Forms.Button();
            this.QueryStopBtn = new System.Windows.Forms.Button();
            this.query_textbox = new System.Windows.Forms.TextBox();
            this.run_btn = new System.Windows.Forms.Button();
            this.schema_combo = new System.Windows.Forms.ComboBox();
            this.selectedTableName = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tableList_listBox);
            this.groupBox1.Location = new System.Drawing.Point(13, 68);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(294, 131);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "TableList";
            // 
            // tableList_listBox
            // 
            this.tableList_listBox.FormattingEnabled = true;
            this.tableList_listBox.Location = new System.Drawing.Point(8, 13);
            this.tableList_listBox.Name = "tableList_listBox";
            this.tableList_listBox.Size = new System.Drawing.Size(286, 108);
            this.tableList_listBox.TabIndex = 0;
            this.tableList_listBox.SelectedIndexChanged += new System.EventHandler(this.tableList_listBox_SelectedIndexChanged);
            // 
            // btnRefreshTableList
            // 
            this.btnRefreshTableList.Location = new System.Drawing.Point(224, 37);
            this.btnRefreshTableList.Name = "btnRefreshTableList";
            this.btnRefreshTableList.Size = new System.Drawing.Size(81, 27);
            this.btnRefreshTableList.TabIndex = 2;
            this.btnRefreshTableList.Text = "Refresh";
            this.btnRefreshTableList.UseVisualStyleBackColor = true;
            this.btnRefreshTableList.Click += new System.EventHandler(this.btnRefreshTableList_Click);
            // 
            // getColumnData_btn
            // 
            this.getColumnData_btn.Enabled = false;
            this.getColumnData_btn.Location = new System.Drawing.Point(211, 254);
            this.getColumnData_btn.Name = "getColumnData_btn";
            this.getColumnData_btn.Size = new System.Drawing.Size(97, 27);
            this.getColumnData_btn.TabIndex = 1;
            this.getColumnData_btn.Text = "Get ColumnData";
            this.getColumnData_btn.UseVisualStyleBackColor = true;
            this.getColumnData_btn.Click += new System.EventHandler(this.getColumnData_btn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_check_uncheck_all);
            this.groupBox2.Controls.Add(this.column_listBox);
            this.groupBox2.Location = new System.Drawing.Point(13, 287);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(294, 135);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ColumnList";
            // 
            // btn_check_uncheck_all
            // 
            this.btn_check_uncheck_all.Location = new System.Drawing.Point(183, 15);
            this.btn_check_uncheck_all.Name = "btn_check_uncheck_all";
            this.btn_check_uncheck_all.Size = new System.Drawing.Size(110, 20);
            this.btn_check_uncheck_all.TabIndex = 1;
            this.btn_check_uncheck_all.Text = "check/uncheck all";
            this.btn_check_uncheck_all.UseVisualStyleBackColor = true;
            this.btn_check_uncheck_all.Click += new System.EventHandler(this.btn_check_uncheck_all_Click);
            // 
            // column_listBox
            // 
            this.column_listBox.CheckOnClick = true;
            this.column_listBox.FormattingEnabled = true;
            this.column_listBox.Location = new System.Drawing.Point(8, 14);
            this.column_listBox.Name = "column_listBox";
            this.column_listBox.Size = new System.Drawing.Size(286, 109);
            this.column_listBox.TabIndex = 0;
            this.column_listBox.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.column_listBox_ItemCheck);
            this.column_listBox.SelectedValueChanged += new System.EventHandler(this.column_listBox_SelectedValueChanged);
            // 
            // getData_btn
            // 
            this.getData_btn.Enabled = false;
            this.getData_btn.Location = new System.Drawing.Point(17, 424);
            this.getData_btn.Name = "getData_btn";
            this.getData_btn.Size = new System.Drawing.Size(85, 23);
            this.getData_btn.TabIndex = 4;
            this.getData_btn.Text = "Get Data";
            this.getData_btn.UseVisualStyleBackColor = true;
            this.getData_btn.Click += new System.EventHandler(this.getData_ctn_Click);
            // 
            // clear_btn
            // 
            this.clear_btn.Enabled = false;
            this.clear_btn.Location = new System.Drawing.Point(220, 424);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(85, 23);
            this.clear_btn.TabIndex = 6;
            this.clear_btn.Text = "Clear";
            this.clear_btn.UseVisualStyleBackColor = true;
            this.clear_btn.Click += new System.EventHandler(this.clear_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.Enabled = false;
            this.save_btn.Location = new System.Drawing.Point(55, 453);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(93, 23);
            this.save_btn.TabIndex = 6;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = true;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // previous_btn
            // 
            this.previous_btn.Enabled = false;
            this.previous_btn.Location = new System.Drawing.Point(121, 424);
            this.previous_btn.Name = "previous_btn";
            this.previous_btn.Size = new System.Drawing.Size(85, 23);
            this.previous_btn.TabIndex = 6;
            this.previous_btn.Text = "Previous";
            this.previous_btn.UseVisualStyleBackColor = true;
            this.previous_btn.Click += new System.EventHandler(this.previous_btn_Click);
            // 
            // commit_btn
            // 
            this.commit_btn.Enabled = false;
            this.commit_btn.Location = new System.Drawing.Point(181, 453);
            this.commit_btn.Name = "commit_btn";
            this.commit_btn.Size = new System.Drawing.Size(93, 23);
            this.commit_btn.TabIndex = 6;
            this.commit_btn.Text = "Commit";
            this.commit_btn.UseVisualStyleBackColor = true;
            this.commit_btn.Click += new System.EventHandler(this.commit_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Selected Table";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(3, 8);
            this.progressBar1.MarqueeAnimationSpeed = 30;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(316, 11);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.TabIndex = 9;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.QueryClearBtn);
            this.groupBox3.Controls.Add(this.QueryStopBtn);
            this.groupBox3.Controls.Add(this.query_textbox);
            this.groupBox3.Controls.Add(this.run_btn);
            this.groupBox3.Location = new System.Drawing.Point(15, 478);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(293, 117);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Query";
            // 
            // QueryClearBtn
            // 
            this.QueryClearBtn.Location = new System.Drawing.Point(89, 88);
            this.QueryClearBtn.Name = "QueryClearBtn";
            this.QueryClearBtn.Size = new System.Drawing.Size(75, 23);
            this.QueryClearBtn.TabIndex = 4;
            this.QueryClearBtn.Text = "Clear";
            this.QueryClearBtn.UseVisualStyleBackColor = true;
            this.QueryClearBtn.Click += new System.EventHandler(this.QueryClearBtn_Click);
            // 
            // QueryStopBtn
            // 
            this.QueryStopBtn.Location = new System.Drawing.Point(8, 88);
            this.QueryStopBtn.Name = "QueryStopBtn";
            this.QueryStopBtn.Size = new System.Drawing.Size(75, 23);
            this.QueryStopBtn.TabIndex = 3;
            this.QueryStopBtn.Text = "Stop";
            this.QueryStopBtn.UseVisualStyleBackColor = true;
            this.QueryStopBtn.Click += new System.EventHandler(this.QueryStopBtn_Click);
            // 
            // query_textbox
            // 
            this.query_textbox.Location = new System.Drawing.Point(7, 20);
            this.query_textbox.Multiline = true;
            this.query_textbox.Name = "query_textbox";
            this.query_textbox.Size = new System.Drawing.Size(268, 62);
            this.query_textbox.TabIndex = 2;
            // 
            // run_btn
            // 
            this.run_btn.Location = new System.Drawing.Point(181, 88);
            this.run_btn.Name = "run_btn";
            this.run_btn.Size = new System.Drawing.Size(97, 23);
            this.run_btn.TabIndex = 1;
            this.run_btn.Text = "Run";
            this.run_btn.UseVisualStyleBackColor = true;
            this.run_btn.Click += new System.EventHandler(this.run_btn_Click);
            // 
            // schema_combo
            // 
            this.schema_combo.FormattingEnabled = true;
            this.schema_combo.Location = new System.Drawing.Point(15, 41);
            this.schema_combo.Name = "schema_combo";
            this.schema_combo.Size = new System.Drawing.Size(203, 21);
            this.schema_combo.TabIndex = 11;
            this.schema_combo.SelectedIndexChanged += new System.EventHandler(this.schema_combo_SelectedIndexChanged);
            // 
            // selectedTableName
            // 
            this.selectedTableName.Location = new System.Drawing.Point(26, 218);
            this.selectedTableName.Name = "selectedTableName";
            this.selectedTableName.ReadOnly = true;
            this.selectedTableName.Size = new System.Drawing.Size(279, 20);
            this.selectedTableName.TabIndex = 12;
            // 
            // UserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.getColumnData_btn);
            this.Controls.Add(this.btnRefreshTableList);
            this.Controls.Add(this.schema_combo);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.selectedTableName);
            this.Controls.Add(this.commit_btn);
            this.Controls.Add(this.previous_btn);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.clear_btn);
            this.Controls.Add(this.getData_btn);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "UserControl";
            this.Size = new System.Drawing.Size(339, 625);
            this.Load += new System.EventHandler(this.UserControl_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox tableList_listBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button getData_btn;
        private System.Windows.Forms.Button clear_btn;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.Button previous_btn;
        private System.Windows.Forms.Button commit_btn;
        private System.Windows.Forms.CheckedListBox column_listBox;
        private System.Windows.Forms.Button getColumnData_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button run_btn;
        private System.Windows.Forms.Button btnRefreshTableList;
        private System.Windows.Forms.Button btn_check_uncheck_all;
        private System.Windows.Forms.TextBox query_textbox;
        private System.Windows.Forms.ComboBox schema_combo;
        private System.Windows.Forms.Button QueryClearBtn;
        private System.Windows.Forms.Button QueryStopBtn;
        private System.Windows.Forms.TextBox selectedTableName;
    }
}
