﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ELS_PLUS_ADDIN.dialogs;
using Microsoft.Office.Tools.Ribbon;

namespace ELS_PLUS_ADDIN
{
    [ComVisible(true)]
    public partial class TopRibbon
    {
        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {

        }
        private void button1_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.TaskPane.Visible = true;
        }


        private void getData_rbtn_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.userControl.getData_ctn_Click(sender, (EventArgs)e);
        }

        private void prev_rbtn_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.userControl.previous_btn_Click(sender, (EventArgs)e);
        }

        private void clear_rbtn_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.userControl.clear_btn_Click(sender, (EventArgs)e);
        }

        private void save_rbtn_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.userControl.save_btn_Click(sender, (EventArgs)e);
        }

        private void commit_rbtn_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.userControl.commit_btn_Click(sender, (EventArgs)e);
        }

        private void showPane_rbtn_Click(object sender, RibbonControlEventArgs e)
        {
//            MessageBox.Show("Show Task Pane Clicked:");
            if (Globals.ThisAddIn.TaskPane.Visible == false)
            {
                Globals.ThisAddIn.TaskPane.Visible = true;
                this.showPane_rbtn.Label = "Hide taskpane";
                this.showPane_rbtn.OfficeImageId = "VisibilityHidden";
            } else
            {
                Globals.ThisAddIn.TaskPane.Visible = false;
                this.showPane_rbtn.Label = "Show taskpane";
                this.showPane_rbtn.OfficeImageId = "VisibilityVisible";
            }
        }

        public void onChangeTaskPaneVisibility(bool visible)
        {
            if (visible == true)
            {
                this.showPane_rbtn.Label = "Hide taskpane";
                this.showPane_rbtn.OfficeImageId = "VisibilityHidden";
            }
            else
            {
                this.showPane_rbtn.Label = "Show taskpane";
                this.showPane_rbtn.OfficeImageId = "VisibilityVisible";
            }
        }


        private void btn_create_new_dataset_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.userControl.onCreatePrestageDataset();
        }

        private void btn_save_dataset_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.userControl.onSavePrestageDataset();
        }

        private void btn_show_dataset_Click(object sender, RibbonControlEventArgs e)
        {
            Globals.ThisAddIn.userControl.showTable();
        }

        private void btnSetting_Click(object sender, RibbonControlEventArgs e)
        {
            using (python_setting_dialog dialog = new python_setting_dialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    Utils.crrPyUrl = dialog.testPyUrl;
                }
            }
        }
        private void toggleButton1_Click(object sender, RibbonControlEventArgs e)
        {
            Utils.crrPyUrl = Utils.gcpPyUrl;
            toggleButton1.Checked = true;
            toggleButton2.Checked = false;
            Globals.ThisAddIn.userControl.initiateControls();
        }
        private void toggleButton2_Click(object sender, RibbonControlEventArgs e)
        {
            Utils.crrPyUrl = Utils.snowflakePyUrl;
            toggleButton1.Checked = false;
            toggleButton2.Checked = true;
            Globals.ThisAddIn.userControl.initiateControls();
        }


    }


}
