import axios from 'axios'
import MockAdapter from 'axios-mock-adapter'

const mock = new MockAdapter(axios)
// Ensure OpenAI API is not intercepted
mock.onAny(/https:\/\/api\.openai\.com/).passThrough();

export default mock
