// Define a Set with allowed characters
const allowedChars = new Set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890 _".split(''));

/*

// Example usage:
console.log(isAllowedString("Valid_String_123")); // true
console.log(isAllowedString("Invalid-String!"));  // false
*/
// Function to check if a string contains only allowed characters
export function isAllowedString(str) {
  return str.split('').every(c => allowedChars.has(c));
}


export function SanitizeInput(input) {
  return input.trim().replace(' ', '_');
}


export function removeBlankRowCols(origin, isZeroBased) {

  if (!origin)
    return [];

  let rowCount = origin.length;
  let colCount = origin[0].length;

  // Adjust for zero-based arrays if not already.
  if (!isZeroBased) {
    let temp = [];
    for (let i = 0; i < rowCount; i++) {
      temp[i] = [];
      for (let j = 0; j < colCount; j++) {
        temp[i][j] = origin[i][j];
      }
    }
    origin = temp;
  }

  let realRowCount = 0,
    realColCount = 0,
    rowOptimizedArray = [];

  // Optimize rows
  for (let i = 0; i < rowCount; i++) {
    let hasNonNull = origin[i].some(cell => cell !== null);
    if (hasNonNull) {
      rowOptimizedArray.push([...origin[i]]);
      realRowCount++;
    }
  }

  // Optimize columns
  let colOptimizedArray = [];
  for (let i = 0; i < realRowCount; i++) {
    colOptimizedArray[i] = [];
  }

  for (let i = 0; i < colCount; i++) {
    let hasNonNull = false;
    for (let j = 0; j < realRowCount; j++) {
      if (rowOptimizedArray[j][i] !== null) {
        hasNonNull = true;
        break;
      }
    }
    if (hasNonNull) {
      for (let j = 0; j < realRowCount; j++) {
        colOptimizedArray[j][realColCount] = rowOptimizedArray[j][i];
      }
      realColCount++;
    }
  }

  // Final data
  let result = [];
  for (let i = 0; i < realRowCount; i++) {
    result[i] = colOptimizedArray[i].slice(0, realColCount);
  }

  return result;
}



export function getColumnTypeFromColumnData(columnData) {
  let resultType = "";

  columnData.forEach(data => {
    if (data === null)
      return;

    let type = checkStringType(data.toString());
    if (resultType === "")
      resultType = type;
    else if (resultType === "INTEGER" && type === "FLOAT")
      resultType = type;
    else if (type === "STRING")
      resultType = type;
  });

  return resultType === "" ? "STRING" : resultType;
}

export function getColumnNamesAndTypes(dataArray) {
  let rowCount = dataArray.length;
  let colCount = dataArray[0].length;

  let columnNames = new Array(colCount);
  let columnTypes = new Array(colCount);

  for (let i = 0; i < colCount; i++) {
    columnNames[i] = dataArray[0][i].toString();

    let columnData = new Array(rowCount - 1);
    for (let j = 1; j < rowCount; j++) {
      columnData[j - 1] = dataArray[j][i];
    }

    columnTypes[i] = getColumnTypeFromColumnData(columnData);
  }

  return {
    columnNames: columnNames,
    columnTypes: columnTypes
  };
}

export function extractNameAndVersion(onlyTableId) {
  // Regular Expression to match 'name' with an optional '_v' followed by an optional version number
  const regex = /^(.+?)(_v(\d+))?$/;
  const matches = onlyTableId.match(regex);

  if (matches) {
    return {
      name: matches[1],
      version: matches[3] ? parseInt(matches[3], 10) : undefined
    };
  } else {
    throw new Error('String does not match the expected format');
  }
}

export function getNextVersionTableId(tableName, tableNames) {

  let terms = tableName.split('.');
  let targetInfo = extractNameAndVersion(terms[1]);

  let nextVersion = 0;
  if (targetInfo.version != null) {
    nextVersion = targetInfo.version + 1;
  }

  for(let one of tableNames) {
    let terms = one.split('.');
    let info = extractNameAndVersion(terms[1]);
    if (info.version != null && info.version >= nextVersion)
      nextVersion = info.version + 1;
  }

  return targetInfo.name + '_v' + nextVersion;
}


export function getPreviousVersionTableId(tableName, tableNames) {

  let targetInfo = extractNameAndVersion(tableName);

  if (targetInfo.version == null) {
    return tableName;
  }

  let versionNumbers = [];

  for(let one of tableNames) {
    let terms = one.split('.');
    let info = extractNameAndVersion(terms[1]);
    if (info.version != null && one !== tableName && info.name === targetInfo.name && info.version < targetInfo.version)
      versionNumbers.push(info.version);
  }

  if (versionNumbers.length === 0)
    return tableName;

  versionNumbers.sort(function(a, b) {
    return b - a;
  });


  return targetInfo.name + '_v' + versionNumbers[0];
}

function checkStringType(str) {
  // Check if str is an integer
  if (/^-?\d+$/.test(str)) {
    return "INTEGER";
  }
  // Check if str is a float
  else if (/^-?\d+\.\d+$/.test(str)) {
    return "FLOAT";
  }
  // Otherwise, it's a string
  else {
    return "STRING";
  }
}



export function headerColumnMissed(dataArray) {
  let columnCount = 0;
  while(dataArray[0][columnCount] != null) { columnCount ++; }

  if (columnCount === 0)
    return true;

  let dataColumnCount = 0;
  while(dataArray[1][dataColumnCount] != null) { dataColumnCount ++; }

  if (dataColumnCount > columnCount) {
    return true;
  }

  return false;
}


export function isOkayToSave(sheet) {
  let selections = sheet.getSelections();
  if (selections.length > 0 && selections[0].rowCount > 1 && selections[0].colCount > 1) {
    let selection = selections[0];
    let dataArray = sheet.getArray(selection.row < 0 ? 0 : selection.row, selection.col, selection.rowCount, selection.colCount);

    if (headerColumnMissed(dataArray)) {
      return "HEADER_COLUMN_MISSED"
    }

    return "OKAY"
  }

  return "ERROR_NOT_SELECT"
}

export function getSelectionDataArray(sheet) {
  let selections = sheet.getSelections();
  if (selections.length > 0) {
    let selection = selections[0];
    return sheet.getArray(selection.row < 0 ? 0 : selection.row, selection.col, selection.rowCount, selection.colCount);
  }

  return [];
}
