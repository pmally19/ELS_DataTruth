// ** MUI Imports
import Box from '@mui/material/Box'

// ** Components
import ModeToggler from 'src/@core/layouts/components/shared-components/ModeToggler'
import UserDropdown from 'src/@core/layouts/components/shared-components/UserDropdown'
import ToolBar from 'src/pages/home/tool-bar'

const AppBarContent = props => {
  // ** Props
  const { settings, saveSettings } = props

  return (
    <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
      {/* Left-aligned ToolBar and ModeToggler */}
      <Box sx={{ display: 'flex', alignItems: 'center', width: '100%'  }}>
        <ToolBar />
      </Box>

      {/* Right-aligned UserDropdown */}
      <Box sx={{ display: 'flex', alignItems: 'center'}}>
        <ModeToggler settings={settings} saveSettings={saveSettings} />
        <UserDropdown settings={settings} sx={{ marginLeft: 'auto' }} />
      </Box>
    </Box>
  )
}

export default AppBarContent
