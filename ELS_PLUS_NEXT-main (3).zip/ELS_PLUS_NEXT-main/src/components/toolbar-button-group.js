import Typography from "@mui/material/Typography";

const ToolBarButtonGroup = ({ children, description }) => {
  return (
    <div style={{
      borderRight: `1px solid #ddd`,
    }}>
      <div className="flex-center"
           style={{
             fontSize: '10px',
             fontWeight: 600,
             color: 'text.primary',
             textTransform: 'capitalize',
             borderBottom: `1px solid #ddd`,
            //  paddingTop: '4px'
      }}>
        {description}
      </div>
      <div>
        {children}
      </div>
    </div>
  )
}

export default ToolBarButtonGroup
