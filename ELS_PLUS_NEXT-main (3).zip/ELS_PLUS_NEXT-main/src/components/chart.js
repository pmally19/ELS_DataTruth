// MyChart.js
import React, {useContext, useEffect} from 'react';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  LineElement, 
  PointElement,
  BarElement, 
  ArcElement, 
  RadialLinearScale,
  Title,
  Filler, 
  Tooltip, 
  Legend 
} from 'chart.js';

import { Bar, Line, Doughnut, Radar, PolarArea, Pie, Scatter, Bubble } from 'react-chartjs-2';

import { HomeContext } from "../context/homeContext";

// Register required modules for Chart.js
ChartJS.register(
    CategoryScale, 
    LinearScale, 
    BarElement, 
    LineElement, 
    PointElement,
    ArcElement, 
    Title, 
    Filler, 
    RadialLinearScale,
    Tooltip, 
    Legend
);

const bgCollection = [
  'rgba(255, 99, 132, 0.2)',
  'rgba(54, 162, 235, 0.2)',
  'rgba(255, 206, 86, 0.2)',
  'rgba(75, 192, 192, 0.2)',
  'rgba(153, 102, 255, 0.2)',
  'rgba(255, 159, 64, 0.2)',
]

const borderCollection = []

const DataChart = ({ chartType, title, index }) => {

  const {homeStore, setHomeStore} = useContext(HomeContext);

  const currentData = homeStore.chartList[homeStore.selected][index];

  const data = {
    labels: currentData.labels,
    datasets: currentData.dataList.map((row, index) => ({
                  label: row.label,
                  data: row.datasets,
                  backgroundColor: bgCollection[index % bgCollection.length],
              }))
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: false,
        text: title,
      },
    },
  };

  if (chartType == "HorizontalBar" || chartType == "StackedHBar") {
    options.indexAxis = 'y';
    options.elements = {
      bar: {
        borderWidth: 2,
      }
    }
    console.log(options);
  }

  if (chartType.includes("Stacked")) {
    options.scales = {
      x: {
        stacked: true,
      },
      y: {
        stacked: true,
      }
    }
  } 

  if (chartType == "MultiAxisLine"){
    options.interaction = {
      mode: 'index',
      intersect: false,
    }
    options.stacked = false;
    options.scales = {
      y: {
        type: 'linear',
        display: true,
        position: 'left',
      },
      y1: {
        type: 'linear',
        display: true,
        position: 'right',
        grid: {
          drawOnChartArea: false,
        }
      }
    }
  }

  if (chartType == "Scatter" || chartType == "Bubble") {
    options.scales = {
      y: {
        beginAtZero: true,
      },
    }
  }

  if (chartType.includes("Bar")) {
    return <Bar data={data} options={options} />;
  }
  if (chartType.includes("Line")){
    return <Line data={data} options={options} />;
  }
  switch(chartType) {
    case "Pie":
      return <Pie data={data} />;
    case "Doughnut":
      return <Doughnut data={data} />;
    case "Polar":
      return <PolarArea data={data} />;
    case "Radar":
      return <Radar data={data} />;
    case "Scatter":
      return <Scatter options={options} data={data} />;
    case "Bubble":
      return <Bubble options={options} data={data} />;
  }
  return <></>
};

export default DataChart;
