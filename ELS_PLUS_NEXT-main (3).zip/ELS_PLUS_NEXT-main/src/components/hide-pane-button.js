import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import {Icon} from "@iconify/react";
import Tooltip from "@mui/material/Tooltip";


const HidePaneButton = ({ tooltip, onClick }) => {
  return (
    <Tooltip title={tooltip}>
      <Button
        onClick={onClick}
        color='primary'
        variant='contained'
        sx={{
          width: 20,
          height: 20,
          minWidth: '20px !important',
          minHeight: 20,
          padding: 0
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
          <Icon width={12}
                height={12}
                // style={{color: '#727272'}}
                icon='mdi:hide'
          />
  {/*
          <Typography variant='body2' sx= {{
            minHeight: '2.4rem;',
            fontWeight: 600,
            color: 'text.primary',
            textTransform: 'capitalize' }}>
            {category}
          </Typography>
  */}
        </Box>
      </Button>
    </Tooltip>
  )
}

export default HidePaneButton
