import {TabContext, TabList} from "@mui/lab";
import {Tab} from "@mui/material";
import {useEffect, useState, useContext} from "react";
import {styled} from "@mui/material/styles";
import styles from "../../styles/pages/kendo-tab-strip.module.scss"
import IconButton from "@mui/material/IconButton";
import {CloseIcon} from "next/dist/client/components/react-dev-overlay/internal/icons/CloseIcon";
import {Icon} from "@iconify/react";
import Fab from "@mui/material/Fab";
import {HomeContext} from "../context/homeContext";




const CustomTabLabel = ({ label, onClose }) => (
  <div style={{ display: 'flex', alignItems: 'center' }}>
    {label}
    <IconButton size="small" onClick={onClose} className={'close-button ' + styles.tabCloseButton}>
      <CloseIcon fontSize="small" />
    </IconButton>
  </div>
);


const CustomizedTabList = styled(TabList)(({ theme }) => ({
  '& .MuiTabs-indicator': {
    display: 'none'
  },
  '& .Mui-selected': {
    backgroundColor: theme.palette.primary.main,
    color: '#fff !important',
    '& .close-button ': {
      color: '#fff',
    }
  },
  '& .MuiTab-root': {
    minHeight: 38,
    minWidth: 110,
    borderRadius: 8,
    paddingTop: theme.spacing(2),
    paddingBottom: theme.spacing(2)
}
}))


let maxIndex = 2;
const KendoTabStrip = () => {
  const {homeStore, setHomeStore} = useContext(HomeContext);


  const handleChange = (event, newValue) => {
    if (homeStore.spreadRef) {
      homeStore.spreadRef.setActiveSheetIndex(newValue);
      setHomeStore((prev) => ({...prev, selected: newValue}));
    }
  }

  const handleClose = tabValue => {

    if (homeStore.spreadRef && homeStore.spreadRef.getSheetCount() > 1) {
      let crrIndex = 0;
      let newTabs = homeStore.tabs.filter((item, index) => {
        if (item.value !== tabValue)
          return true;
        crrIndex = index;
        return false;
      })
      newTabs = newTabs.map((item, index) => {
        item.value = index;

        return item;
      });
      
      let nextSelected = 0;
      if (homeStore.selected !== tabValue)
        nextSelected = homeStore.selected;
      else if (tabValue === homeStore.spreadRef.getSheetCount() - 1)
        nextSelected = tabValue - 1;
      else
        nextSelected = tabValue;

      homeStore.spreadRef.removeSheet(tabValue);
      homeStore.spreadRef.setActiveSheetIndex(nextSelected);

      let chartList = homeStore.chartList.filter((chart, index) => index != crrIndex);
      setHomeStore((prev) => ({
        ...prev, 
        selected: nextSelected, 
        tabs: newTabs, 
        chartList: chartList,
        actionEvent: {
          key: "RemoveSheetLayout",
          params: {
            sheetIndex: crrIndex
          }
        }
      }));
    }
  };


  const handleAddSheet = () => {
    if (homeStore.spreadRef) {
      const spread = homeStore.spreadRef;
      let newSheetIndex = spread.getSheetCount();
      setHomeStore((prev) => ({...prev, tabs: [...prev.tabs,
        {
          name: 'sheet' + (maxIndex ++),
          value: newSheetIndex
        }
      ]}));

      spread.addSheet(newSheetIndex);
      spread.setActiveSheetIndex(newSheetIndex);
      setHomeStore((prev) => ({
        ...prev, 
        selected: newSheetIndex, 
        chartList: [...homeStore.chartList, []],
        actionEvent: {
          key: 'NewSheetLayout',
          params: {}
        }
      }));
      window.setDefaultOption2Sheet(spread.getActiveSheet());
    }
  }

  return (
    <div className={styles.kendoTabStrip}>
      <TabContext value={homeStore.selected}>
        <CustomizedTabList onChange={handleChange} aria-label='customizedTabList'>
          {
            homeStore.tabs.map((tab, index) =>
              <Tab
                key={index}
                value={tab.value}
                label={
                <CustomTabLabel
                  label={tab.name}
                  onClose={() => handleClose(tab.value)}
                />
              }></Tab>
            )
          }

          <div className={styles.addButton}>
            <Fab color='dangererror' aria-label='add' size='small' onClick={handleAddSheet}>
              <Icon icon='mdi:plus' />
            </Fab>
          </div>

        </CustomizedTabList>
      </TabContext>
    </div>
  )
}

export default KendoTabStrip
