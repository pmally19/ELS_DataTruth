import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import {Icon} from "@iconify/react";
import Tooltip from "@mui/material/Tooltip";


const FormulaBarButton = ({ displayName, icon, onClick }) => {
  return (
    <Tooltip title={displayName}>
      <Button
        onClick={onClick}
        variant='rounded'
        sx={{
          width: 32,
          height: 32,
          backgroundColor: 'transparent',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
          <Icon
                style={{color: '#727272'}}
                icon={icon}
          />
        </Box>
      </Button>
    </Tooltip>
  )
}

export default FormulaBarButton
