import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import Tooltip from "@mui/material/Tooltip"; // Import Tooltip
import { Icon } from "@iconify/react";

const ToolbarButton = ({ category, icon, onClick }) => {
  return (
    <Tooltip title={category} arrow>
      <Button
        onClick={onClick}
        variant="rounded"
        sx={{
          width: 30,
          height: 30,
          backgroundColor: "transparent",
          minWidth: "unset",
          padding: 5,
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", flexDirection: "column" }}>
          <Icon width={30} height={30} style={{ color: "#727272" }} icon={icon} />
        </Box>
      </Button>
    </Tooltip>
  );
};

export default ToolbarButton;
