"use client";

import React, {useContext, useState, useEffect, useRef } from "react";
import GridLayout from "react-grid-layout";

import Card from '@mui/material/Card'
import IconButton from '@mui/material/IconButton';
import CancelIcon from '@mui/icons-material/Cancel';

import { SpreadSheets } from "../@core/krapecity/spread-sheets-react";
import * as GC from "../@core/krapecity/spread-sheets";
import * as XLSX from "xlsx";  // Import the xlsx library

import DataChart from "./chart";
import KendoTabStrip from "./KendoTabStrip";

import { HomeContext } from "../context/homeContext";
import styles from "../../styles/pages/home.module.scss"


export default function SpreadSheet() {

  const {homeStore, setHomeStore} = useContext(HomeContext);

  const [draglayout, setDragLayout] = useState([[{ i: "1", x: 0, y: 0, w: 10, h: 4 }]]);

  const divSpreadRef = useRef(null);
  const [spreadSize, setSpreadSize] = useState({});

  // spreadsheet resize.
  useEffect(() => {
    const handleResize = (entries) => {
      triggerResizeEvent();
      for (let entry of entries) {
        const { width, height } = entry.contentRect;
        setSpreadSize({ width, height });
      }
    };
    const resizeObserver = new ResizeObserver(handleResize);
    if (divSpreadRef.current) {
      resizeObserver.observe(divSpreadRef.current);
    }
    return () => {
      resizeObserver.disconnect();
    };
  }, []);

  // action event
  useEffect(() => {
    if (!homeStore.actionEvent) 
      return;
    let key = homeStore.actionEvent.key;
    let params = homeStore.actionEvent.params;
    if (key == "NewSheetLayout") {
      setDragLayout((prev) => [...prev, [{ i: "1", x: 0, y: 0, w: 10, h: 4 }]]);
    }
    if (key == "RemoveSheetLayout") {
      let layouts = draglayout;
      layouts = layouts.filter((rr, ii) => ii != params.sheetIndex);
      setDragLayout(layouts);
    }
    if (key == "AddChart") {
      handleCreateChart(params);
    }
    setHomeStore((prev) => ({...prev, actionEvent: null}));
  }, [homeStore.actionEvent]);

  // spreadsheet set init.
  const initSpread = (spread) => {
    setHomeStore((prev) => ({...prev, spreadRef: spread}));

    let fbx = new GC.Spread.Sheets.FormulaTextBox.FormulaTextBox(document.getElementById('formulaBar'));
    fbx.workbook(spread);

    let activeSheet = spread.getActiveSheet();
    spread.options.tabStripVisible = false;
    spread.options.tabStripPosition = 1;

    const sheets = spread.sheets;
    sheets.forEach(sheet => {
      sheet.bind(GC.Spread.Sheets.Events.CellChanged, (e, args) => {
        handleCellChange(sheet, args.row, args.col);
      });
    });

    window.setDefaultOption2Sheet = setDefaultOption2Sheet;
    window.clearSheet = clearSheet;
    window.triggerResizeEvent = triggerResizeEvent;
    window.showDataToCurrentSheet = showDataToCurrentSheet;
    // Bind cell selection change event
    activeSheet.bind(GC.Spread.Sheets.Events.SelectionChanged, (e) => {
      const selection = activeSheet.getSelections();
      if (selection.length > 0) {
        const { row, col, rowCount, colCount } = selection[0];
        const data = extractData(activeSheet, row, col, rowCount, colCount);
        updateChart(data); // Update chart with the new data
      }
    });

    // initSheet(activeSheet);
    setDefaultOption2Sheet(activeSheet);
    spread.resumePaint();
  }

  const initSheet = function (sheet) {
    sheet.suspendPaint();
    //prepare data for chart
    let dataArray = [
        ["", 'Chrome', 'FireFox', 'IE', 'Safari', 'Edge', 'Opera', 'Other'],
        ["2015", 0.5651, 0.1734, 0.1711, 0.427, 0, 0.184, 0.293],
        ["2016", 0.6230, 0.1531, 0.1073, 0.464, 0.311, 0.166, 0.225],
        ["2017", 0.6360, 0.1304, 0.834, 0.589, 0.443, 0.223, 0.246]
    ];
    sheet.setArray(0, 0, dataArray);
    sheet.resumePaint();
  }

  // Function to extract data from the selected range
  const extractData = (sheet, row, col, rowCount, colCount) => {
    const data = [];
    for (let r = row; r < row + rowCount; r++) {
      const rowData = [];
      for (let c = col; c < col + colCount; c++) {
        rowData.push(sheet.getValue(r, c));
      }
      data.push(rowData);
    }
    return data;
  };
  // Function to update chart data and options
  const updateChart = (data) => {
    if (data.length < 2) return; // Check if there's at least a title row and one data row

    const columnCount = data[0].length;

    // Identify the column with the most numbers (ignoring the first row, assuming it's titles)
    let numericColumnIndex = -1;
    let maxNumericCount = 0;

    for (let col = 0; col < columnCount; col++) {
      let numericCount = 0;

      data.slice(1).forEach(row => { // Start from the second row to avoid title row
        if (!isNaN(row[col])) {
          numericCount++;
        }
      });

      if (numericCount > maxNumericCount) {
        maxNumericCount = numericCount;
        numericColumnIndex = col;
      }
    }

    // Set chartValues to the numeric column (excluding the title row) or the second column if no numeric column found,
    // and convert non-numeric values to 0
    const chartValues = numericColumnIndex !== -1
      ? data.slice(1).map(row => !isNaN(row[numericColumnIndex]) ? Number(row[numericColumnIndex]) : 0)
      : data.slice(1).map(row => !isNaN(row[1]) ? Number(row[1]) : 0);

    // Set labels by combining other columns, excluding the numeric column, and excluding the title row
    const labels = data.slice(1).map(row =>
      row.filter((_, idx) => idx !== numericColumnIndex).join(' ')
    );

    // Use the title of the selected numeric column as the dataset label
    const datasetLabel = numericColumnIndex !== -1 ? data[0][numericColumnIndex] : 'Selected Data';

    const datasets = [{
      label: datasetLabel,
      data: chartValues,
      backgroundColor: 'rgba(75, 192, 192, 0.2)',
      borderColor: 'rgba(75, 192, 192, 1)',
      borderWidth: 1,
    }];

    setHomeStore(prev => ({ ...prev, chartData: { labels, datasets } }));
  };

  const triggerResizeEvent = () => {
    var event = document.createEvent('Event');
    event.initEvent('resize', true, true);
    window.dispatchEvent(event);
  }

  const handleCellChange = (sheet, row, col) => {
    const rowCount = sheet.getRowCount();
    const colCount = sheet.getColumnCount();

    // Check if the last row was edited and add a new row
    if (row === rowCount - 1) {
      sheet.addRows(rowCount, 5);
    }

    // Check if the last column was edited and add a new column
    if (col === colCount - 1) {
      sheet.addColumns(colCount, 5);
    }
  }


  const clearSheet = (activeSheet) => {
    const clearOptions = GC.Spread.Sheets.StorageType.All;
    activeSheet.clear(0, 0, activeSheet.getRowCount(), activeSheet.getColumnCount(), GC.Spread.Sheets.SheetArea.viewport, GC.Spread.Sheets.StorageType.data);
    activeSheet.getRange(0, 0, 1, activeSheet.getColumnCount()).backColor("#fff");
    activeSheet.getRange(0, 0, 1, activeSheet.getColumnCount()).foreColor("#222");
  }

  const showDataToCurrentSheet = (spread, rows, isChart) => {
    if (spread && Array.isArray(rows) && rows.length > 0) {
      const sheet = spread.getActiveSheet();
      let columnHeaders = Object.keys(rows[0]);
      let dataArray = [columnHeaders];

      for(let row of rows) {
        dataArray.push(Object.values(row));
      }

      for(let i = 1; i < dataArray.length; i ++) {
        for(let j = 0; j < dataArray[i].length; j ++) {
          if (typeof dataArray[i][j] == "object") {
           dataArray[i][j] = dataArray[i][j].value;
          }
        }
      }

      if (isChart) {
        window.setDataChart(dataArray);
      } else {
        if (sheet.getRowCount() < dataArray.length) {
          sheet.setRowCount(dataArray.length + 10);
        }
  
        if (dataArray.length > 0 && sheet.getColumnCount() < dataArray[0].length) {
          sheet.setColumnCount(dataArray[0].length + 3);
        }
  
  
        window.clearSheet(sheet);
        sheet.setArray(0, 0, dataArray);
        // --- set first row color
        sheet.getRange(0, 0, 1, dataArray[0].length).backColor("#177c43");
        sheet.getRange(0, 0, 1, dataArray[0].length).foreColor("#fff");
      }
    }
  }

  const populateSheetWithData = (sheet, rows) => {
    if (sheet && Array.isArray(rows) && rows.length > 0) {
      // Get column headers from the first row of data
      const columnHeaders = Object.keys(rows[0]);
      const dataArray = [columnHeaders];

      // Populate dataArray with row values
      rows.forEach(row => {
        dataArray.push(Object.values(row));
      });

      // Handle cell objects (e.g., cells with .value property)
      for (let i = 1; i < dataArray.length; i++) {
        for (let j = 0; j < dataArray[i].length; j++) {
          if (typeof dataArray[i][j] === "object") {
            dataArray[i][j] = dataArray[i][j].value;
          }
        }
      }

      // Adjust sheet row and column count as necessary
      if (sheet.getRowCount() < dataArray.length) {
        sheet.setRowCount(dataArray.length + 10); // Add extra rows for flexibility
      }
      if (dataArray[0] && sheet.getColumnCount() < dataArray[0].length) {
        sheet.setColumnCount(dataArray[0].length + 3); // Add extra columns for flexibility
      }

      // Clear previous data or styles on the sheet
      window.clearSheet(sheet);

      // Populate the sheet with the new data
      sheet.setArray(0, 0, dataArray);

      // Apply header styling to the first row
      sheet.getRange(0, 0, 1, dataArray[0].length).backColor("#177c43");
      sheet.getRange(0, 0, 1, dataArray[0].length).foreColor("#fff");

    }
  };


  // This function handles setting the row heights and column widths
  const setDefaultOption2Sheet = (sheet) => {

    const defaultRowHeight = 30; // Your default row height
    const defaultColumnWidth = 100; // Your default column width

    // set header height and width
    sheet.setRowHeight(0, defaultRowHeight, GC.Spread.Sheets.SheetArea.colHeader);
    sheet.setColumnWidth(0, 40, GC.Spread.Sheets.SheetArea.rowHeader);

    // set sheet options
    sheet.options.colHeaderResizable = false;
    sheet.options.rowHeaderResizable = false;
    sheet.options.selectionBackColor = 'rgba(103, 110, 252, .3)';
    sheet.options.selectionBorderColor = 'rgba(103, 110, 252, 1)';
    sheet.options.gridline = {
      color:"#FF2235",
      showVerticalGridline: false,
      showHorizontalGridline: false
    };


    // set sheet default styles
    let defaultStyle = new GC.Spread.Sheets.Style();
    defaultStyle.hAlign = GC.Spread.Sheets.HorizontalAlign.center;
    defaultStyle.vAlign = GC.Spread.Sheets.VerticalAlign.middle;

    // Apply the default style to all cells in the active sheet
    sheet.setDefaultStyle(defaultStyle);

    // set even back colors
    let columnCount = sheet.getColumnCount();
    // Set default row height for all rows
    for (let i = 0; i < sheet.getRowCount(); i++) {
      sheet.setRowHeight(i, defaultRowHeight);
      if (i % 2 === 1) {
        sheet.getRange(i, 0, 1, columnCount).backColor("#eeeeee");
      }
    }

    // Set default column width for all columns
    for (let j = 0; j < sheet.getColumnCount(); j++) {
      sheet.setColumnWidth(j, defaultColumnWidth);
    }

  }


  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: "array" });

        const spread = homeStore.spreadRef;

        // Clear all existing sheets
        const existingSheetCount = spread.getSheetCount();
        for (let i = existingSheetCount - 1; i >= 0; i--) {
          spread.removeSheet(i);
        }

        // Reset tabs and selected state
        setHomeStore((prev) => ({...prev, tabs: [], selected: 0 }));
        // Iterate over each sheet
        workbook.SheetNames.forEach((sheetName) => {

          const spread = homeStore.spreadRef;
          let newSheetIndex = spread.getSheetCount();
          setHomeStore((prev) => ({...prev, tabs: [...prev.tabs,
            {
              name: sheetName,
              value: newSheetIndex
            }
          ]}));

          spread.addSheet(newSheetIndex);
          spread.setActiveSheetIndex(newSheetIndex);
          setHomeStore((prev) => ({...prev, selected: newSheetIndex}));
          window.setDefaultOption2Sheet(spread.getActiveSheet());

          spread.getActiveSheet().bind(GC.Spread.Sheets.Events.SelectionChanged, (e) => {
            const selection = spread.getActiveSheet().getSelections();
            if (selection.length > 0) {
              const { row, col, rowCount, colCount } = selection[0];
              const data = extractData(spread.getActiveSheet(), row, col, rowCount, colCount);
              updateChart(data); // Update chart with the new data
            }
          });
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet);

          // Display data for each sheet
          populateSheetWithData(spread.getSheet(newSheetIndex), jsonData);
        });
      };
      reader.readAsArrayBuffer(file);
    }
  };

  // When click graph button
  const handleCreateChart = (params) => {
    if (!homeStore.spreadRef)
      return;
    let sheetIndex = homeStore.selected;
    let activeSheet = homeStore.spreadRef.getActiveSheet();

    let cellRange = activeSheet.getSelections();
    let labels = [], subLabels = [], datasets = [];
    cellRange.map((range, index) => {
      for (let i = range.col + 1; i < range.colCount; i ++) {
        labels.push(activeSheet.getCell(0, i).value());
      }
      for (let i = range.row + 1; i < range.rowCount; i ++) {
        subLabels.push(activeSheet.getCell(i, 0).value());
      }
      for (let r = range.row + 1; r < range.rowCount + range.row; r ++) {
        let data = [];
        for (let c = range.col + 1; c < range.colCount + range.col; c ++) {
          data.push(activeSheet.getCell(r, c).value());
        }
        datasets.push(data);
      }
    });
    if(datasets.length <= 0 || labels.length <= 0)
      return;

    let crrChart = homeStore.chartList[sheetIndex];
    console.log(homeStore.chartList);
    let newChart = {
      isShowChart : true,
      type: params.chartType,
      title: params.chartTitle,
      labels: labels,
      dataList: subLabels.map((label, index) => ({
                  label: label,
                  datasets: datasets[index],
                }))
    }
    crrChart.push(newChart);
    let sheetCharts = homeStore.chartList;
    sheetCharts[sheetIndex] = crrChart;
    setHomeStore((prev) => ({...prev, chartList: sheetCharts}));
    handleSetLayout(crrChart.length);
  }

  const handleSetLayout = (chartCnt) => {
    if (chartCnt == 0) {
      let layout = draglayout;
      layout[homeStore.selected] = [{ i: "1", x: 0, y: 0, w: 10, h: 4 }];
      setDragLayout(layout);
    } else {
      let layArray = [{ i: "1", x: 0, y: 0, w: 7, h: 4 }];
      for (let i = 0; i < chartCnt; i ++) {
        if (i == 0)
          layArray.push({ i: `${i + 2}`, x: 7, y: 0, w: 3, h: 2 })
        if (i == 1)
          layArray.push({ i: `${i + 2}`, x: 7, y: 2, w: 3, h: 2 })
        if (i >= 2) {
          layArray.push({i: `${i + 2}`, x: (i - 2) % 3 * 3, y: ((i - 2) / 3) * 3 + 4, w: 3, h: 3})
        }
      }
      let layout = draglayout;
      layout[homeStore.selected] = layArray;
      setDragLayout(layout);
    }
  }

  const removeChart = (index) => {
    let crrCharts = homeStore.chartList[homeStore.selected].filter((chart, ii) => ii != index);
    let sheetCharts = homeStore.chartList;
    sheetCharts[homeStore.selected] = crrCharts;
    setHomeStore((prev) => ({...prev, chartList: sheetCharts}));
    let layout = draglayout[homeStore.selected].filter((rr, ii) => ii != (index + 1));
    resetLayoutIndex(layout);
  }

  const resetLayoutIndex = (layout) => {
    for (let i = 0; i < layout.length; i ++) {
      layout[i].i = `${i + 1}`;
    }
    let newLayouts = draglayout;
    newLayouts[homeStore.selected] = layout;
    setDragLayout(newLayouts);
  }

  return (
    <div className="p-8">
        <div className={styles.cardContent }>
          <GridLayout
            className="layout"
            layout={draglayout[homeStore.selected]}
            cols={12}
            rowHeight={100}
            width={1200}
            draggableHandle=".drag-handle"
          >
            <div key="1" className="panel">
              <div className="drag-handle">
                Spreadsheet Center
              </div>
              <KendoTabStrip/>
              <Card>
              <input type="file" accept=".xlsx, .xls" onChange={handleFileUpload} />
              {
                <div className={styles.formulaContainer}>
                  <span className={styles.spanText}>fx</span>
                  <div id="formulaBar" className={styles.formulaBar} contentEditable="true" spellCheck="false"></div>
                </div>
              }
              <div ref={divSpreadRef}  style={{height: '100vh' }}>
                  <SpreadSheets
                    workbookInitialized={spread => initSpread(spread)}>
                  </SpreadSheets>
              </div>
              </Card>
            </div>
            {
              homeStore.chartList && homeStore.chartList[homeStore.selected].length > 0 ?
              homeStore.chartList[homeStore.selected].map((crr, index) => {
                  return(
                    <div key={`${index + 2}`} className="panel">
                      <div className="drag-handle">
                        <span>{crr.title ? crr.title : 'Untitled'}</span>
                        <IconButton 
                          color="success" 
                          aria-label="add to shopping cart" 
                          style={{float: 'right', marginTop: '-7px'}}
                          onClick={() => removeChart(index)}
                        >
                          <CancelIcon />
                        </IconButton>
                      </div>
                      <DataChart chartType={crr.type} index={index} chartTitle={crr.title} />
                    </div>
                  )
              }) : <></>
            }
          </GridLayout>
        </div>
    </div>
  );

}
