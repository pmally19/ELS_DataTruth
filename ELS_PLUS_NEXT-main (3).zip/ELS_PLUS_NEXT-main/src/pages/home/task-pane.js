"use client";

import styles from "../../../styles/pages/home.module.scss"
import Card from '@mui/material/Card'
import Typography from '@mui/material/Typography'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import Button from '@mui/material/Button'
import Select from '@mui/material/Select'
import MenuItem from '@mui/material/MenuItem'
import IconButton from '@mui/material/IconButton'
import Icon from 'src/@core/components/icon'
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from "@mui/material/Checkbox";
import {Tabs, Tab , ListItemText, TextField} from "@mui/material";
import LinearProgress from '@mui/material/LinearProgress'

import {useContext, useEffect, useState} from "react";
import Box from "@mui/material/Box";
import Chip from "@mui/material/Chip";
import {HomeContext} from "../../context/homeContext";
import HidePaneButton from "../../components/hide-pane-button";
import toast from "react-hot-toast";
import StorageIcon from "@mui/icons-material/Storage"; // Icon for BigQuery
import ListAltIcon from "@mui/icons-material/ListAlt"; // Icon for Current Contents
import ChatIcon from '@mui/icons-material/Chat'; // Import the Chat icon
import dynamic from "next/dynamic";

const ITEM_HEIGHT = 48
const ITEM_PADDING_TOP = 8


const MenuProps = {
  PaperProps: {
    style: {
      width: 250,
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP
    }
  }
}

const TaskPane = () => {

  const {homeStore, setHomeStore} = useContext(HomeContext);
  const [columnNames, setColumnNames] = useState([])

  const [tableNames, setTableNames] = useState([])
  const [datasets, setDatasets] = useState([])
  const [tables, setTables] = useState([])

  const [selectedTableName, setSelectedTableName] = useState("")
  const [selectedDataset, setSelectedDataset] = useState("")

  const [selectedColumnNames, setSelectedColumnNames] = useState([])

  const [activeTab, setActiveTab] = useState(0);
  const [showChart, setShowChart] = useState(false);



  const [selectedQuery, setSelectedQuery] = useState("")
  const [bigQueryInput, setBigQueryInput] = useState("");
  const [currentContentsQueryInput, setCurrentContentsQueryInput] = useState("");

  useEffect(() => {
    setProgressStatus('show-progress')
    onMounted()
  }, []);

  const setProgressStatus = (status) => {
    setHomeStore((prev) => ({...prev, progressStatus: status}));
  }

  const onMounted = () => {
    setProgressStatus('show-progress')
    fetch('/api/dataset-tables')
      .then((res) => res.json())
      .then((data) => {
        // if (Array.isArray(data)) {
          setDatasets(data.datasets)
          setTables(data.tables);
          // if(data.tables.length > 0) setTableNames(data.tables[]);
          setHomeStore((prev) => ({...prev, dataSets: data.datasets}));
        // }
        setProgressStatus('hide-progress')
      });
  }

  const onGetColumnNamesByTableName = (tableName) => {
    setProgressStatus('show-progress')
    fetch(`/api/column-names?tableName=${tableName}`)
      .then((res) => res.json())
      .then((data) => {
        console.log(data);

        setColumnNames(data);
        // console.log("onGetColumn", homeStore);
        setHomeStore({...homeStore, currentColumnNames: data});

        setProgressStatus('hide-progress')
      });
  }

  const handleColumnSelectChanged = event => {
    setSelectedColumnNames(event.target.value)
  }

  const handleQuerySelectChanged = event => {
    if (event.target.value !== "") {
      if (selectedQuery !== event.target.value) {
        setSelectedQuery(event.target.value);
      }
    }
  }
  const handleDatasetSelectChanged = event => {

    if (event.target.value !== "") {

      if (selectedDataset !== event.target.value) {

        setColumnNames([]) // initialize column names
        setSelectedColumnNames([]);
      }

      setSelectedDataset(event.target.value);
      console.log("setHomeStore", {...homeStore, currentDataset: event.target.value})
      setHomeStore((prev) => ({...prev, currentDataset: event.target.value}));
      setTableNames(tables[event.target.value]);
      //onGetColumnNamesByTableName(event.target.value);
      setSelectedColumnNames([]);
    }
  }

  const handleTableSelectChanged = event => {

    if (event.target.value !== "") {

      if (selectedTableName !== event.target.value) {

        setColumnNames([]) // initialize column names
        setSelectedColumnNames([]);
      }

      setSelectedTableName(event.target.value);
      console.log("setHomeStore", {...homeStore, currentTableName: event.target.value})
      setHomeStore((prev) => ({...prev, currentTableName: event.target.value}));
      setSelectedColumnNames([]);
      onGetColumnNamesByTableName(selectedDataset + '.' + event.target.value);
    }
  }

  const handleRefreshTableList = () => {
    setSelectedTableName("")
    // setHomeStore({...homeStore, currentTableName: ''});

    setSelectedColumnNames([])
    setTableNames([])
    onMounted();
  }

  let params = {
    tableName: selectedDataset + '.' + selectedTableName,
    columnNames: selectedColumnNames
  };

  const handleShowResult = (isChart) => {
    setProgressStatus('show-progress')
    fetch('/api/table-data-by-column-names', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(params)
    })
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          toast.error(data.error);
        }
        console.log(data)
        window.showDataToCurrentSheet(homeStore.spreadRef, data, isChart)
        setProgressStatus('hide-progress')

      })
      .catch(error => {
        setProgressStatus('hide-progress')
      });

  }


  const handleSave = () => {

  }


  const handleCommit = () => {

  }
  const showDataToCurrentSheet = (spread, rows) => {
    if (spread && Array.isArray(rows) && rows.length > 0) {
      const sheet = spread.getActiveSheet();
      let columnHeaders = Object.keys(rows[0]);
      let dataArray = [columnHeaders];

      for(let row of rows) {
        dataArray.push(Object.values(row));
      }

      for(let i = 1; i < dataArray.length; i ++) {
        for(let j = 0; j < dataArray[i].length; j ++) {
          if (typeof dataArray[i][j] == "object" && dataArray[i][j] != null ) {
           dataArray[i][j] = dataArray[i][j].value;
          }
        }
      }

      console.log("dataArray", dataArray);

      if (sheet.getRowCount() < dataArray.length) {
        sheet.setRowCount(dataArray.length + 10);
      }

      if (dataArray.length > 0 && sheet.getColumnCount() < dataArray[0].length) {
        sheet.setColumnCount(dataArray[0].length + 3);
      }


      window.clearSheet(sheet);
      sheet.setArray(0, 0, dataArray);
      // --- set first row color
      sheet.getRange(0, 0, 1, dataArray[0].length).backColor("#177c43");
      sheet.getRange(0, 0, 1, dataArray[0].length).foreColor("#fff");
      // ###  set first row color

      // spread.getWorkbook().invalidateLayout();
      // spread.getWorkbook().repaint();
      console.log(sheet);
      // window.setDefaultOption2Sheet(sheet);

    }
  }
  const getSheetContent = () => {
    const sheet = homeStore.spreadRef.getActiveSheet()
    const rowCount = sheet.getRowCount();
    const colCount = sheet.getColumnCount();
    let sheetContent = [];

    for (let i = 0; i < rowCount; i++) {
      let rowContent = [];
      for (let j = 0; j < colCount; j++) {
        rowContent.push(sheet.getValue(i, j));
      }
      sheetContent.push(rowContent);
    }

    return sheetContent;
  };
  const handleQueryRun = () =>  {

    const question = activeTab === 0 ? document.getElementById("bigQueryInput").value : document.getElementById("currentContentsQueryInput").value;
    const datasetId = selectedDataset;
    const tableName = selectedTableName; // Update with the selected table name
    const contentData = getSheetContent();
    setProgressStatus('show-progress');

    if (!question) {
      toast.error("Please enter a question.");
      setProgressStatus('hide-progress');
      return;
    }
    // Adjust fetch URL or parameters based on query type
    const apiUrl = activeTab === 0 ? '/api/big-query' : '/api/current-content-query';
    const requestBody = activeTab === 0
      ? { question, datasetId, tableName }
      : { question, contentData };

    fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    })
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          toast.error(data.error);
        } else {
          console.log("here!")
          console.log(data.result);
          console.log("end")
          // document.getElementById("sqlOutput").innerText = data.generated_sql;
          // setHomeStore((prev) => ({...prev, queryResult: data.executed_sql}));
          showDataToCurrentSheet(homeStore.spreadRef, data.result);
        }
        setProgressStatus('hide-progress');
      })
      .catch(error => {
        console.error("Error:", error);
        toast.error("An error occurred while generating the SQL query.");
        setProgressStatus('hide-progress');
      });
  }

const handleTabChange = (event, newValue) => {
  setActiveTab(newValue);
};


  return (
      <div className={styles.panelContainer} style={{display: homeStore.taskPaneVisible ? 'inherit' : 'none'}}>
        <Card>
          <div className={homeStore ? homeStore.progressStatus : ''}>
            <LinearProgress/>
          </div>
          <CardHeader title='ELS+ Task Pane'></CardHeader>
          <CardContent>
            {/*<Button variant='contained' color='primary'>Refresh</Button>*/}

            <div className="mb-8">
              {/* <Typography className="p-header mb-4" sx={{mb: 2, fontWeight: 500}}>TableList</Typography> */}

              <FormControl fullWidth  style={{ marginBottom: '16px' }}>
                <div className="d-flex pr-20px">
                  <Select
                    value={selectedDataset}
                    onChange={handleDatasetSelectChanged}
                    className="w-100" defaultValue='' displayEmpty inputProps={{'aria-label': 'Without label'}}>
                    {datasets && datasets.map(Dataset => (
                      <MenuItem key={'1' + Dataset} value={Dataset}>
                        {Dataset}
                      </MenuItem>
                    ))}
                  </Select>

                  <IconButton
                    onClick={handleRefreshTableList}
                    variant='contained' aria-label='capture screenshot' color='primary' size='small'>
                    <Icon icon='zondicons:reload' fontSize='inherit'/>
                  </IconButton>
                </div>
              </FormControl>

              <FormControl fullWidth>
                <div className="d-flex pr-20px">
                  <Select
                    value={selectedTableName}
                    onChange={handleTableSelectChanged}
                    className="w-100" defaultValue='' displayEmpty inputProps={{'aria-label': 'Without label'}}>
                    {tableNames && tableNames.map(tableName => (
                      <MenuItem key={'1' + tableName} value={tableName}>
                        {tableName}
                      </MenuItem>
                    ))}
                  </Select>

                </div>
              </FormControl>
            </div>


            {
              (selectedTableName !== "" &&
                (<>
                  <div className="mb-4">
                    <Typography className="p-header mb-4" sx={{mb: 2, fontWeight: 500}}>Select Column Names</Typography>
                    <FormControl fullWidth>
                      <InputLabel>Column Names</InputLabel>
                      <Select
                        multiple
                        label='Chip'
                        value={selectedColumnNames}
                        MenuProps={MenuProps}
                        onChange={handleColumnSelectChanged}
                        id='demo-multiple-checkbox'
                        labelId='demo-multiple-checkbox-label'
                        renderValue={selected => (
                          <Box sx={{display: 'flex', flexWrap: 'wrap'}}>
                            {selected && selected.map(value => (
                              <Chip key={value} label={value} sx={{m: 0.75}}/>
                            ))}
                          </Box>
                        )}
                      >
                        {columnNames && columnNames.map(columnName => (
                          <MenuItem key={columnName} value={columnName}>
                            <Checkbox checked={selectedColumnNames.indexOf(columnName) > -1}/>
                            <ListItemText primary={columnName}/>
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </div>

                  {
                    (columnNames.length > 0 &&
                      (
                        <>
                          <div className="flex-center mb-4">
                            <Button
                              disabled={selectedColumnNames.length === 0}
                              onClick={() => handleShowResult(false)}
                              variant='contained' color='primary'>Display Data</Button>
                          </div>
                          <div className="flex-center mb-4">
                          <Button
                              disabled={selectedColumnNames.length === 0}
                              onClick={() => handleShowResult(true)}
                              variant='contained' color='primary'>Display Chart</Button>
                          </div>
                        </>
                      ))
                  }




                </>)
              )
            }
                  {/* Tabs for switching between query types */}
                  <Tabs
                      value={activeTab}
                      onChange={handleTabChange}
                      indicatorColor="primary"
                      textColor="primary"
                      variant="fullWidth"
                  >
                    <Tab
                        icon={<StorageIcon />}
                        label="DataBase Copilot"
                        sx={{ fontSize: '10px' }} // Change '12px' to your desired font size
                    />
                    <Tab
                        icon={<ListAltIcon />}
                        label="Document Copilot"
                        sx={{ fontSize: '10px' }} // Change '12px' to your desired font size
                    />
                  </Tabs>

                  {/* Conditionally render the query input based on the active tab */}
                  {activeTab === 0 ? (
                      <TextField
                          id="bigQueryInput"
                          multiline
                          minRows={4}
                          maxRows={10}
                          variant="outlined"
                          fullWidth
                          placeholder="Enter BigQuery query here"
                          value={bigQueryInput}
                          onChange={(e) => setBigQueryInput(e.target.value)}
                      />
                  ) : (
                      <TextField
                          id="currentContentsQueryInput"
                          multiline
                          minRows={4}
                          maxRows={10}
                          variant="outlined"
                          fullWidth
                          placeholder="Enter query for current contents here"
                          value={currentContentsQueryInput}
                          onChange={(e) => setCurrentContentsQueryInput(e.target.value)}
                      />
                  )}

                  <div className="flex-center mb-4 mt-4">
                      <Button
                          onClick={handleQueryRun}
                          variant="contained"
                          color="primary"
                          startIcon={<ChatIcon />}
                      >
                          Run
                      </Button>
                  </div>



          </CardContent>
        </Card>

        <div style={{
          position: 'absolute',
          right: '20px',
          top: '18px'
        }}>
          <HidePaneButton tooltip={'hide taskpane'} onClick={() => {
            window.triggerResizeEvent();
            setHomeStore((prev) => ({...homeStore, taskPaneVisible: false}))
          }}/>
        </div>

      </div>
  );

}

export default TaskPane
