"use client"
import {useContext, useEffect, useRef, useState} from 'react';
import TaskPane from "./task-pane";
import styles from "../../../styles/pages/home.module.scss"
import dynamic from "next/dynamic";
import ToolBar from "./tool-bar";
import {HomeContext} from "../../context/homeContext";
import ResizeableWidget from './resizable-widget'

const SpreadSheet = dynamic(
  () => {
    return import("../../components/SpreadSheet");
  },
  { ssr: false }
);


const Home = () => {

  const {homeStore, setHomeStore} = useContext(HomeContext);

  return (
      <div className={styles.homeContainer}>

        <div className={styles.spreadSheet + (homeStore.taskPaneVisible ? '' : ' ' + styles.fullWidth) } >
          <SpreadSheet/>
        </div>

        <TaskPane/>

      </div>
  );

}

export default Home
