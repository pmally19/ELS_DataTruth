"use client";
import styles from "../../../styles/pages/home.module.scss"
import Paper from '@mui/material/Paper';
import Card from '@mui/material/Card'
import Popover from '@mui/material/Popover';
import TextField from '@mui/material/TextField';
import { styled, useTheme } from '@mui/material/styles'
import Grid from '@mui/material/Grid';
import PopupState, { bindTrigger, bindPopover } from 'material-ui-popup-state';

import {useContext, useEffect, useState} from "react";
import {HomeContext} from "../../context/homeContext";
import ToolbarButton from "../../components/toolbar-button";
import ToolBarButtonGroup from "../../components/toolbar-button-group";
import CreateDatasetDialog from "./dialogs/create-dataset-dialog";
import ShowDatasetDialog from "./dialogs/show-dataset-dialog";
import HidePaneButton from "../../components/hide-pane-button";
import {
  getColumnNamesAndTypes,
  getNextVersionTableId, getPreviousVersionTableId,
  getSelectionDataArray,
  isOkayToSave,
  removeBlankRowCols
} from "../../utils";
import toast from 'react-hot-toast'

const ITEM_HEIGHT = 48
const ITEM_PADDING_TOP = 8

const MenuProps = {
  PaperProps: {
    style: {
      width: 250,
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP
    }
  }
}

const ChartIcon = styled('img')(({ theme }) => ({
  width: '40px',
  maxWidth: '12rem',
  [theme.breakpoints.down('xl')]: {
    maxWidth: '10rem'
  },
  [theme.breakpoints.down('lg')]: {
    maxWidth: '8rem'
  }
}))

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
  ...theme.applyStyles('dark', {
    backgroundColor: '#1A2027',
  }),
}));


const ToolBar = () => {

  const [visibleCreateNewDatasetDialog, setVisibleCreateNewDatasetDialog] = useState(false);
  const [visibleShowDatasetDialog, setVisibleShowDatasetDialog] = useState(false);
  const {homeStore, setHomeStore} = useContext(HomeContext);
  const [sheetHeaderVisible, setSheetHeaderVisible] = useState(true);
  const [chartTitle, setChartTitle] = useState("");

  useEffect(() => {
    onMounted()
  }, []);

  const onMounted = () => {
  }


  const onClickCreateDataset = () => {
    let sheet = homeStore.spreadRef.getActiveSheet();

    // check before save
    let checkResult = isOkayToSave(sheet);
    if (checkResult === 'HEADER_COLUMN_MISSED') {
      toast.error("There is missing column names in first row")
      return;
    } else if (checkResult === 'ERROR_NOT_SELECT') {
      toast.error("You need to select range")
      return;
    }

    setVisibleCreateNewDatasetDialog(true);
  }

  const onClickSaveDataset = () => {
    const {currentTableName, currentDataset} = homeStore;
    if (currentDataset !== "Prestage" || currentTableName === '')
      return;

    if (currentTableName === '') {
      toast.error("you didn't select table to save");
      return;
    }

    let sheet = homeStore.spreadRef.getActiveSheet();
    // check before save
    let checkResult = isOkayToSave(sheet);
    if (checkResult === 'HEADER_COLUMN_MISSED') {
      toast.error("There is missing column names in first row")
      return;
    } else if (checkResult === 'ERROR_NOT_SELECT') {
      toast.error("You need to select range")
      return;
    }


    // normalize data
    let dataArray = getSelectionDataArray(sheet);
    dataArray = removeBlankRowCols(dataArray, true);

    let tempValue = getColumnNamesAndTypes(dataArray);


    let params = {
      datasetId: 'Prestage',
      tableId: currentTableName,
      columnNames: tempValue.columnNames,
      columnTypes: tempValue.columnTypes,
      dataArray
    };

    setProgressStatus('show-progress');
    fetch('/api/update-table', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(params)
    })
      .then(response => response.json())
      .then(data => {
        toast.success("saved successfully");
        setProgressStatus('hide-progress')

      })
      .catch(error => {
        toast.error("unexpected error!");
        setProgressStatus('hide-progress')
      });

  }

  const saveChart = (datasetId, tableId) => {
    let sheet = homeStore.spreadRef.getActiveSheet();
    let chartList = sheet.charts.all();
    let dataList = [];
    chartList.map((chart, index) => {
        let title = chart.title().text;
        console.log(title);
    });
  }

  const onCloseCreateDatasetDialog = (dialogResult, tableId) => {
    setVisibleCreateNewDatasetDialog(false);

    if (dialogResult === true) {

      let sheet = homeStore.spreadRef.getActiveSheet();
      // normalize data
      let dataArray = getSelectionDataArray(sheet);
      dataArray = removeBlankRowCols(dataArray, true);

      let tempValue = getColumnNamesAndTypes(dataArray);

      (async () => {
        await saveTable('Prestage', tableId, tempValue.columnNames, tempValue.columnTypes, dataArray);
        await saveChart('Prestage', tableId);
        onCloseShowDatasetDialog(true, 'Prestage.' + tableId);
      })();

    }

  }

  const onClickShowDataset = () => {
    setVisibleShowDatasetDialog(true);
  }

  const onClickBtnSave = () => {

    const {currentTableName, currentColumnNames} = homeStore;
    if (currentTableName === '') {
      toast.error("you didn't select table to save");
      return;
    }

    let sheet = homeStore.spreadRef.getActiveSheet();
    console.log("sheet", sheet);

    // check before save
    let checkResult = isOkayToSave(sheet);
    if (checkResult === 'HEADER_COLUMN_MISSED') {
      toast.error("There is missing column names in first row")
      return;
    } else if (checkResult === 'ERROR_NOT_SELECT') {
      toast.error("You need to select range")
      return;
    }


    // normalize data
    let dataArray = getSelectionDataArray(sheet);
    dataArray = removeBlankRowCols(dataArray, true);

    let tempValue = getColumnNamesAndTypes(dataArray);

    console.log(tempValue, dataArray);
    saveTableAsNewVersion('Query_Save', tempValue.columnNames, tempValue.columnTypes, dataArray);
    // Task.Run(() => run_cmd($"google prestage-save {Utils.currentPrestageTableId} {payload}"));
  }

  const onClickBtnCommit = () => {

    const {currentTableName, currentColumnNames} = homeStore;
    if (currentTableName === '') {
      toast.error("you didn't select table to save");
      return;
    }

    let sheet = homeStore.spreadRef.getActiveSheet();
    console.log("sheet", sheet);

    // check before save
    let checkResult = isOkayToSave(sheet);
    if (checkResult === 'HEADER_COLUMN_MISSED') {
      toast.error("There is missing column names in first row")
      return;

    } else if (checkResult === 'ERROR_NOT_SELECT') {
      toast.error("You need to select range")
      return;

    }


    // normalize data
    let dataArray = getSelectionDataArray(sheet);
    dataArray = removeBlankRowCols(dataArray, true);

    let tempValue = getColumnNamesAndTypes(dataArray);
    saveTableAsNewVersion('Commit', tempValue.columnNames, tempValue.columnTypes, dataArray);
    // Task.Run(() => run_cmd($"google prestage-save {Utils.currentPrestageTableId} {payload}"));
  }


  const onClickBtnPrevious = () => {

    const {currentTableName, currentDataset, currentColumnNames} = homeStore;
    if (currentTableName === '') {
      toast.error("you didn't select table to save");
      return;
    }

    let datasetId = currentDataset;

    setProgressStatus('show-progress')

    fetch(`/api/tables?datasetId=${datasetId}`)
      .then((res) => res.json())
      .then((tableNames) => {

        if (Array.isArray(tableNames)) {
          let previousTableName = getPreviousVersionTableId(currentTableName, tableNames);
          setHomeStore((prev) => ({...prev, currentTableName: previousTableName}));

          let params = {
            tableName: datasetId + '.' + previousTableName
          };

          fetch('/api/table-data', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(params)
          })
            .then(response => response.json())
            .then(data => {
              if (data.error) {
                toast.error(data.error);
              }
              console.log(data)
              window.showDataToCurrentSheet(homeStore.spreadRef, data)
              setProgressStatus('hide-progress')

            })
            .catch(error => {
              setProgressStatus('hide-progress')
            })


        } else {
          toast.error("error occured~!");
          setProgressStatus('hide-progress')
        }

      });

  }

  const setProgressStatus = (status) => {
    setHomeStore((prev) => ({...prev, progressStatus: status}));
  }


  const onCloseShowDatasetDialog = (dialogResult, selectedDatasetName) => {

    setVisibleShowDatasetDialog(false);

    if (dialogResult === true) {

      let params = {
        tableName: selectedDatasetName
      };
      console.log(params);
      setProgressStatus('show-progress');
      fetch('/api/table-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
      })
        .then(response => response.json())
        .then(data => {
          if (data.error) {
            toast.error(data.error);
          }

          setHomeStore((prev) => ({...prev, currentTableName: selectedDatasetName}));

          window.showDataToCurrentSheet(homeStore.spreadRef, data)
          setProgressStatus('hide-progress')

        })
        .catch(error => {
          setProgressStatus('hide-progress')
        })


    }

  }

  const handleSwitchHeaderVisibility = () => {
    if (homeStore.spreadRef) {
      const activeSheet = homeStore.spreadRef.getActiveSheet();
      activeSheet.options.colHeaderVisible = !activeSheet.options.colHeaderVisible;
      activeSheet.options.rowHeaderVisible = !activeSheet.options.rowHeaderVisible;

      setSheetHeaderVisible(activeSheet.options.colHeaderVisible);

    }
  }



  const autofitContent = () => {
    if (homeStore.spreadRef) {
      const activeSheet = homeStore.spreadRef.getActiveSheet();
      for (let col = 0; col < 10; col++) {
        activeSheet.autoFitColumn(col);
      }

    }
  }

  const onClearSheet = () => {
    if (homeStore.spreadRef) {
      const activeSheet = homeStore.spreadRef.getActiveSheet();
      window.clearSheet(activeSheet);
      // activeSheet.clear(0, 0, activeSheet.getRowCount(), activeSheet.getColumnCount(), GC.Spread.Sheets.SheetArea.viewport, GC.Spread.Sheets.StorageType.All);
    }
  }


  const saveTableAsNewVersion = (datasetId, columnNames, columnTypes, dataArray) => {

    const {currentTableName, tableNames} = homeStore;
    setProgressStatus('show-progress')

    let newTableId = getNextVersionTableId(currentTableName, tableNames);

    let params = {
      datasetId,
      tableId: newTableId,
      columnNames,
      columnTypes,
      dataArray
    };

    fetch('/api/create-table', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(params)
    })
      .then(response => response.json())
      .then(data => {
        // console.log(data)
        // showDataToCurrentSheet(data)
        // update current table name
        let newTableName = datasetId + '.' + newTableId;
        if (datasetId === 'Commit') {
          setHomeStore((prev) => ({...prev, currentTableName: newTableName}));
        } else {
          setHomeStore((prev) => ({...prev, currentTableName: newTableName, tableNames: [...tableNames, newTableName]}))
        }

        toast.success("saved successfully");
        setProgressStatus('hide-progress')

      })
      .catch(error => {
        toast.error("unexpected error!");
        setProgressStatus('hide-progress')
      });

  }

  const saveTable = (datasetId, tableId, columnNames, columnTypes, dataArray) => {

    return new Promise((resolve, reject) => {

      setProgressStatus('show-progress')

      let params = {
        datasetId,
        tableId,
        columnNames,
        columnTypes,
        dataArray
      };

      fetch('/api/create-table', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
      })
        .then(response => response.json())
        .then(data => {
          console.log(data);
          let newTableName = tableId;
          setHomeStore((prev) => ({...prev, currentTableName: newTableName}));

          /*
                  window.clearSheet(spreadRef.getActiveSheet());
                  spreadRef.getActiveSheet().setArray(dataArray);
          */

          resolve(params);
          toast.success("saved successfully");
          setProgressStatus('hide-progress')

        })
        .catch(error => {
          toast.error("unexpected error!");
          setProgressStatus('hide-progress')
          reject();
        });

    });



  }


  const onCreateChart = (chartType) => {
    setHomeStore((prev) => ({
      ...prev,
      actionEvent: {
        key: "AddChart",
        params: {
          chartType,
          chartTitle
        }
      }
    }));
    setChartTitle("");
  };

  return (
    <div className={styles.toolbarContainer} style={{display: homeStore.toolbarVisible ? 'inherit' : 'none'}}>
      <Card>
        <div style={{display: 'flex', position: 'relative'}}>

          <ToolBarButtonGroup description="Setting">
            <ToolbarButton
              category={sheetHeaderVisible ? 'Hide Headers' : 'Show Headers'}
              icon={sheetHeaderVisible ? 'mdi:hide' : 'mdi:show'}
              onClick={handleSwitchHeaderVisibility}/>
            <ToolbarButton category='AutoFit Columns' icon='tabler:arrow-autofit-content' onClick={autofitContent}/>
          </ToolBarButtonGroup>

          <ToolBarButtonGroup description="Version Action">
            <ToolbarButton category='Clear' icon='mdi:eraser' onClick={onClearSheet}/>
            <ToolbarButton category='Save' icon='material-symbols:save-rounded' onClick={onClickBtnSave}/>
            <ToolbarButton category='Commit' icon='material-symbols:commit' onClick={onClickBtnCommit}/>
            <ToolbarButton category='Previous' icon='mdi:comment-previous-outline' onClick={onClickBtnPrevious}/>
            {/*<ToolbarButton category='Get Data' icon='mdi:get-app'/>*/}
          </ToolBarButtonGroup>

          <ToolBarButtonGroup description="New Dataset">
            <ToolbarButton category='Create Dataset' icon='mdi:create-new-folder' onClick={onClickCreateDataset}/>
            <ToolbarButton category='Save Dataset' icon='mdi:content-save-check' onClick={onClickSaveDataset}/>
            <ToolbarButton category='Show Dataset' icon='mdi:list-box' onClick={onClickShowDataset}/>
          </ToolBarButtonGroup>
          <ToolBarButtonGroup description="Planning">
            <ToolbarButton category="Proportionate" icon="mdi:percent" />
            <ToolbarButton category="Equal" icon="mdi:scale-balance" />
            <ToolbarButton category="Time Series" icon="mdi:timer" />
            <ToolbarButton category="Top&Bottom" icon="mdi:arrow-up-down" />
            <ToolbarButton category="Lock Data" icon="mdi:lock" />
          </ToolBarButtonGroup>
          <ToolBarButtonGroup description="Graph">
            <PopupState variant="popover" popupId="demo-popup-popover">
                {(popupState) => (
                  <div>
                    <ToolbarButton 
                      variant="contained" 
                      {...bindTrigger(popupState)} 
                      category='Show Graph' 
                      icon="mdi:chart-bar" 
                      // onClick={onCreateChart}
                    />
                    <Popover
                      {...bindPopover(popupState)}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'center',
                      }}
                      transformOrigin={{
                        vertical: 'top',
                        horizontal: 'center',
                      }}
                    >
                      <div className={styles.graphPopover}>
                        <div style={{display: 'block'}}>
                          <TextField 
                            id="outlined-basic" 
                            label="Chart Title" 
                            variant="outlined" 
                            value={chartTitle}
                            onChange={(e) => setChartTitle(e.target.value)}
                            fullWidth 
                          />
                        </div>
                        <Grid container spacing={5} style={{marginTop: '0px', marginLeft: '0px'}}>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("VerticalBar")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/vertical-bar.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("HorizontalBar")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/horizontal-bar.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("StackedVBar")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/stacked-v-bar.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("StackedHBar")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/stacked-h-bar.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                        </Grid>
                        {/* next row */}
                        <Grid container spacing={5} style={{marginTop: '0px', marginLeft: '0px'}}>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("Line")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/line.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("MultiAxisLine")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/multiaxis-line.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("Pie")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/pie.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("Doughnut")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/doughnut.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                        </Grid>
                        {/* next row */}
                        <Grid container spacing={5} style={{marginTop: '0px', marginLeft: '0px'}}>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("Polar")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/polar.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("Radar")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/radar.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("Scatter")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/scatter.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                          <Grid size={3}>
                            <Item>
                              <button onClick={() => onCreateChart("Bubble")}>
                                <ChartIcon
                                  alt='Column Chart'
                                  src={'/images/pages/chart-icon/bubble.png'}
                                />
                              </button>
                            </Item>
                          </Grid>
                        </Grid>
                      </div>
                    </Popover>
                  </div>
                )}
            </PopupState>
          </ToolBarButtonGroup>
          <ToolBarButtonGroup description="Schedule">
            <ToolbarButton category='Create Schedule' icon="mdi:calendar-check" />
          </ToolBarButtonGroup>
          <ToolBarButtonGroup description="Prediction">
            <ToolbarButton category="Create Model" icon="mdi:chart-line" />          {/* Create Model: Chart or data line icon */}
            <ToolbarButton category="Display Model" icon="mdi:table" />              {/* Display Model: Table icon */}
            <ToolbarButton category="Predictions" icon="mdi:chart-bell-curve" />     {/* Predictions: Curve or analytics icon */}
          </ToolBarButtonGroup>
          {/* <div style={{
            display: (homeStore && homeStore.currentTableName !== '') ? 'block' : 'none',
            position: 'absolute',
            bottom: '8px',
            right: '15px',
            padding: '5px 10px',
            background: '#676efc',
            borderRadius: '22px',
            color: 'white'
          }}>
            { homeStore && homeStore.currentTableName }
          </div> */}
          <div style={{
            position: 'absolute',
            right: '5px',
            top: '2px'
          }}>
            <HidePaneButton tooltip={'hide toolbar'} onClick={()=>{
              window.triggerResizeEvent();
              setHomeStore((prev) => ({...prev, toolbarVisible: false}));
            }}/>
          </div>
        </div>
      </Card>

      <CreateDatasetDialog open={visibleCreateNewDatasetDialog} handleClose={onCloseCreateDatasetDialog}/>
      <ShowDatasetDialog open={visibleShowDatasetDialog} handleClose={onCloseShowDatasetDialog}/>
    </div>
  );

}

export default ToolBar
