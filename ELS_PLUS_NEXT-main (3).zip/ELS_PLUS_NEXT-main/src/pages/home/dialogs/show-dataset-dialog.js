// ** React Imports
import {Fragment, useEffect, useState} from 'react'

// ** MUI Imports
import Button from '@mui/material/Button'
import Dialog from '@mui/material/Dialog'
import TextField from '@mui/material/TextField'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import DialogActions from '@mui/material/DialogActions'
import DialogContentText from '@mui/material/DialogContentText'
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import LinearProgress from "@mui/material/LinearProgress";
import {getPreviousVersionTableId} from "../../../utils";
import toast from "react-hot-toast";

const ShowDatasetDialog = ({open, handleClose}) => {
  // ** State
  const [newDatasetName, setNewDatasetName] = useState('');
  const [progressStatus, setProgressStatus] = useState('show-progress');
  const [selectedTableName, setSelectedTableName] = useState('');
  const [tableNames, setTableNames] = useState([]);


  useEffect(() => {

    setProgressStatus('show-progress');

    fetch(`/api/tables?datasetId=Prestage`)
      .then((res) => res.json())
      .then((tableNames) => {
        if (Array.isArray(tableNames)) {

          tableNames = tableNames.map((item) => {
            return item.replace('Prestage.', '');
          })

          setTableNames(tableNames);
        }
        // else {
        //   toast.error("error occured~!");
        // }
        setProgressStatus('hide-progress')
      });


  }, [open]);


  const onDialogClose = (result) => {
    handleClose(result, 'Prestage.' + selectedTableName);
  }

  const handleTableSelectChanged = (event) => {
    setSelectedTableName(event.target.value);
  }

  return (
    <Dialog open={open} onClose={() => {
      onDialogClose(false)
    }} aria-labelledby='form-dialog-title'>
      <div className={progressStatus}>
        <LinearProgress/>
      </div>
      <DialogTitle id='form-dialog-title'>Show New Dataset</DialogTitle>
      <DialogContent>
        <DialogContentText sx={{mb: 3}}>
          Please select dataset name
        </DialogContentText>
        <Select
          value={selectedTableName}
          onChange={handleTableSelectChanged}
          className="w-100" defaultValue='' displayEmpty inputProps={{'aria-label': 'Without label'}}>
          {tableNames && tableNames.map(tableName => (
            <MenuItem key={'1' + tableName} value={tableName}>
              {tableName}
            </MenuItem>
          ))}
        </Select>
      </DialogContent>
      <DialogActions className='dialog-actions-dense'>
        <Button onClick={() => {
          onDialogClose(false)
        }}>Cancel</Button>
        <Button onClick={() => {
          onDialogClose(true)
        }}>Ok</Button>
      </DialogActions>
    </Dialog>
  )
}

export default ShowDatasetDialog
