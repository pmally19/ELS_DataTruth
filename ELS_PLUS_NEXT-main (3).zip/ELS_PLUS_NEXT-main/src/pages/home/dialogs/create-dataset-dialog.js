// ** React Imports
import {Fragment, useEffect, useState} from 'react'

// ** MUI Imports
import Button from '@mui/material/Button'
import Dialog from '@mui/material/Dialog'
import TextField from '@mui/material/TextField'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import DialogActions from '@mui/material/DialogActions'
import DialogContentText from '@mui/material/DialogContentText'
import {isAllowedString} from "../../../utils";
import Alert from "@mui/material/Alert";
import Typography from "@mui/material/Typography";
import toast from "react-hot-toast";

const CreateDatasetDialog = ({open, handleClose}) => {
  // ** State
  const [newDatasetName, setNewDatasetName] = useState('');

  useEffect(() => {
    setNewDatasetName('');
  }, [open]);

  const onDialogClose = (result) => {
    if (result === true && !isAllowedString(newDatasetName)) {
      alert('please insert correct dataset name');
      return;
    }
    handleClose(result, newDatasetName);
  }

  const onNameChange = (event) => {
    setNewDatasetName(event.target.value);
  }

  return (
    <Dialog open={open} onClose={() => {onDialogClose(false)}} aria-labelledby='form-dialog-title'>
      <DialogTitle id='form-dialog-title'>Create New Dataset</DialogTitle>
      <DialogContent>
        <DialogContentText sx={{ mb: 3 }}>
          Please input new dataset name
        </DialogContentText>
        <TextField id='name' autoFocus fullWidth type='email' label='New Dataset' value={newDatasetName} onChange={onNameChange}/>
      </DialogContent>
      <DialogActions className='dialog-actions-dense'>
        <Button onClick={() => { onDialogClose(false) }}>Cancel</Button>
        <Button onClick={() => { onDialogClose(true) }}>Ok</Button>
      </DialogActions>
    </Dialog>
  )
}

export default CreateDatasetDialog
