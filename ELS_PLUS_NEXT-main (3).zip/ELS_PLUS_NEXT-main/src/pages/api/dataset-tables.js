// pages/api/get-all-tables.js
import myBigquery from "./my-bigquery";

export default function handler(req, res) {

  (async function(){

    // Handle the request based on req.method
    let tableList = {};
    let datasetList = [];
    let {datasetId} = req.query;

    try {
      const datasets = await myBigquery.getDatasets();
      for (const dataset of datasets[0]) {

        if (datasetId != null) {
          if (dataset.id !== datasetId)
            continue;
        }
        datasetList.push(dataset.id);
        const [tables] = await dataset.getTables();
        let tl = [];
        for (const table of tables) {
          tl.push(table.id);
        }
        tableList[dataset.id] = tl;
      }
      let data = {
        datasets: datasetList,
        tables: tableList
      }
      res.status(200).json(data);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to retrieve tables from BigQuery' });
    }

  })();
}
