// pages/api/get-all-tables.js
import myBigquery from "./my-bigquery";

export default function handler(req, res) {

  (async function(){

    // Handle the request based on req.method
    let tableList = [];
    let {datasetId} = req.query;
    try {
      const datasets = await myBigquery.getDatasets();
      for (const dataset of datasets[0]) {

        if (datasetId != null) {
          if (dataset.id !== datasetId)
            continue;
        }

        const [tables] = await dataset.getTables();
        for (const table of tables) {
          tableList.push(`${dataset.id}.${table.id}`);
        }
      }
      res.status(200).json(tableList);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to retrieve tables from BigQuery' });
    }

  })();
}
