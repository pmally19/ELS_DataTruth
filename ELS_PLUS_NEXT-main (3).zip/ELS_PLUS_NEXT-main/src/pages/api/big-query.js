import { OpenAI } from 'openai'; // Import OpenAI SDK
import myBigquery from "./my-bigquery";

// In-memory cache to store responses
const cache = new Map();

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});



// Helper function to interact with OpenAI
const askOpenAIForBigQueryFunction = async (query, tableName) => {
  const context = `You are working with a BigQuery table named '${tableName}'. Based on the question below, provide a detailed SQL query that retrieves the specific data requested. Ensure the query meets the requirements stated in the question and include any necessary filtering, aggregation, or sorting.\n\nQuestion: ${query}\n\nSQL Query:`;
  const fullPrompt = context + query;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo', // You can use the model that suits your needs
      messages: [{ role: 'user', content: fullPrompt }],
      max_tokens: 200,
      temperature: 0.5,
    });
    return response.choices[0].message.content.trim();
  } catch (error) {
    console.error("Error communicating with OpenAI API:", error.message);
    return "Error generating BigQuery function suggestion. Please try again later.";
  }
};

// Helper function to get a cached response
const getCachedResponse = (question, datasetId, tableName) => {
  const cacheKey = `${datasetId}.${tableName}_${question}`;
  return cache.get(cacheKey);
};

// Helper function to cache a response
const setCachedResponse = (question, datasetId, tableName, response) => {
  const cacheKey = `${datasetId}.${tableName}_${question}`;
  cache.set(cacheKey, response);
};

// Function to execute SQL query in BigQuery
const executeBigQuery = async (sqlQuery) => {
  try {

    const [rows] = await myBigquery.query(sqlQuery);
    return rows; // Return the rows from the query
  } catch (error) {
    console.error("Error executing BigQuery SQL:", error.message);
    throw new Error("Error executing SQL query. Please check the syntax.");
  }
};

// API handler
export default async function handler(req, res) {
  const { question, datasetId, tableName } = req.body;

  if (!question || !tableName || !datasetId) {
    return res.status(400).json({ error: "Question, dataset ID, and table name are required." });
  }

  // Check cache first
  const cachedResponse = getCachedResponse(question, datasetId, tableName);
  if (cachedResponse) {
    return res.status(200).json({ executed_sql: cachedResponse, cached: true });
  }
  // Get response from OpenAI
  const bigQueryFunctionSuggestion = await askOpenAIForBigQueryFunction(question, `lyrical-country-397623.${datasetId}.${tableName}`);
  if (bigQueryFunctionSuggestion.startsWith("Error")) {
    return res.status(500).json({ error: bigQueryFunctionSuggestion });
  }
  console.log(bigQueryFunctionSuggestion);
  // Execute the generated SQL query
  let executedResult;
  try {
    executedResult = await executeBigQuery(bigQueryFunctionSuggestion);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }

  // Cache the response
  setCachedResponse(question, datasetId, tableName, executedResult);

  // Send response
  res.status(200).json({ result: executedResult, cached: false });
}
