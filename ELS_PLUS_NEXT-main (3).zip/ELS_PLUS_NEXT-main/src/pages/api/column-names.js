// pages/api/get-all-tables.js
import myBigquery from "./my-bigquery";

export default function handler(req, res) {

  (async function(){

    const { tableName } = req.query;

    if (tableName == null) {
      res.status(500).json({ error: 'tableName is empty' });

      return;
    }

    try {
      let terms = tableName.split(".")

      // Get the table reference
      const [table] = await myBigquery.dataset(terms[0]).table(terms[1]).get();

      // Retrieve the schema field from the table object
      const schema = table.metadata.schema;

      // Concatenate all column names with a "#" prefix
      const result = schema.fields.map(field => field.name);

      res.status(200).json(result);

    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to retrieve tables from BigQuery' });
    }

  })();
}
