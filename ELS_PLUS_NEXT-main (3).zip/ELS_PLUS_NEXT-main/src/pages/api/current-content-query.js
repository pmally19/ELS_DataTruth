import { OpenAI } from 'openai'; // Import OpenAI SDK
// In-memory cache to store responses
const cache = new Map();

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const askOpenAIForDataAnalysis = async (query, contentData) => {
  const context = `You are given the following data as a JSON array of objects. Based on the question below, provide an analysis or insight as requested. Return the result as a list of rows, where each row is an object with keys corresponding to the column headers and values representing the data in each cell. Data: ${JSON.stringify(contentData)}\n\nQuestion: ${query}\n\nPlease return the result in the following row format:`;

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo', // Specify the model
      messages: [{ role: 'user', content: context }],
      max_tokens: 500,
      temperature: 0.5,
    });

    // Parse the response to ensure it's in row format
    const result = JSON.parse(response.choices[0].message.content.trim());
    if (Array.isArray(result) && result.every(item => typeof item === 'object')) {
      return result; // Return as rows of objects
    } else {
      throw new Error("Response format error: expected an array of objects.");
    }
  } catch (error) {
    console.error("Error communicating with OpenAI API:", error.message);
    return [{ Error: "Error generating response. Please try again later." }];
  }
};

// Helper function to get a cached response
const getCachedResponse = (question, contentData) => {
  const cacheKey = `${JSON.stringify(contentData)}_${question}`;
  return cache.get(cacheKey);
};

// Helper function to cache a response
const setCachedResponse = (question, contentData, response) => {
  const cacheKey = `${JSON.stringify(contentData)}_${question}`;
  cache.set(cacheKey, response);
};

// API handler
export default async function handler(req, res) {
  const { question, contentData } = req.body;

  if (!question || !contentData) {
    return res.status(400).json({ error: "Question and content data are required." });
  }

  // Check cache first
  const cachedResponse = getCachedResponse(question, contentData);
  if (cachedResponse) {
    return res.status(200).json({ result: cachedResponse, cached: true });
  }

  // Get response from OpenAI using provided content data
  const analysisResult = await askOpenAIForDataAnalysis(question, contentData);
  if (Array.isArray(analysisResult) && analysisResult[0].Error) {
    return res.status(500).json({ error: analysisResult[0].Error });
  }

  // Cache the response
  setCachedResponse(question, contentData, analysisResult);

  // Send response
  res.status(200).json({ result: analysisResult, cached: false });
}
