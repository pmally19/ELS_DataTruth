// pages/api/get-all-tables.js
import myBigquery from "./my-bigquery";

function makeSchema(columnNames, columnTypes) {
  let schema = [];
  for(let i = 0; i < columnNames.length; i ++) {
    schema.push({
      name: columnNames[i],
      type: columnTypes[i],
      mode: 'NULLABLE'
    })
  }

  return schema;
}

export default function handler(req, res) {

  (async function(){

    const { datasetId, tableId, columnNames, columnTypes, dataArray } = req.body;
    try {


      const schema = makeSchema(columnNames, columnTypes);
      const options = {
        schema: schema,
        location: 'US',
      };


      await myBigquery
        .dataset(datasetId)
        .createTable(tableId, options);

      dataArray.splice(0, 1);

      let rows = [];
      for(let rowData of dataArray) {
        let map = {};
        for(let i = 0; i < columnNames.length; i ++) {
          map[columnNames[i]] = rowData[i];
        }

        rows.push(map);
      }

      await myBigquery
        .dataset(datasetId)
        .table(tableId)
        .insert(rows);


      res.status(200).json({result: 'success'});

    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to retrieve tables from BigQuery' });
    }

  })();
}
