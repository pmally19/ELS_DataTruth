import { BigQuery } from '@google-cloud/bigquery';
import googleAccountData from '../../credentials/lyrical-country-397623-26653c08607b.json'

const credentials = {
  projectId: "lyrical-country-397623",
  googleAccountData
};

const myBigquery = new BigQuery({
  projectId: credentials.projectId,
  credentials: credentials.googleAccountData
});

export default myBigquery
