import myBigquery from "./my-bigquery";

export default function handler(req, res) {

  if (req.method !== "POST") {
    res.status(404).json({ error: 'method invalid' });
  }

  (async function(){

    const { tableName } = req.body;

    if (tableName == null ) {
      res.status(500).json({ error: 'invalid params!' });
      return;
    }

    try {
      // Construct the fully qualified table name
      const project_id = await myBigquery.getProjectId();
      const qualifiedTableName = `${project_id}.${tableName}`;

      // Create the SQL query
      const query = `SELECT * FROM \`${qualifiedTableName}\``;
      // Options for the query
      const options = {
        query: query
      };

      const [job] = await myBigquery.createQueryJob(options);
      console.log(`Job ${job.id} started.`);

      // Wait for the query to finish
      const [rows] = await job.getQueryResults();

      res.status(200).json(rows);

    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to retrieve tables from BigQuery' });
    }

  })();
}
