// Create a new file named SharedObjectContext.js or similar
import {createContext, useState} from 'react';

const HomeContext = createContext();

const HomeProvider = ({children}) => {

  const [homeStore, setHomeStore] = useState({
    toolbarVisible: true,
    taskPaneVisible: true,
    chartCtrlVisible: false,
    currentDatasetName: '',
    currentTableName: '',
    dataSets: [],
    tableNames: [],
    currentColumnNames: [],
    currentColumnTypes: [],
    progressStatus: 'hide-progress',
    selected: 0,
    tabs:[{name: 'sheet1', value: 0}],
    isChartOpen:false,
    chartList: [
      []
    ],
    chartData:{ labels: [], datasets: [] },
    chartOptions: { responsive: true, plugins: { legend: { position: 'top' }, title: { display: true, text: 'Selected Data Overview' } } },
    spreadRef:null,
    actionEvent:null,
  });

  return <HomeContext.Provider value={{homeStore, setHomeStore}}>{children}</HomeContext.Provider>
}



export { HomeContext, HomeProvider }
