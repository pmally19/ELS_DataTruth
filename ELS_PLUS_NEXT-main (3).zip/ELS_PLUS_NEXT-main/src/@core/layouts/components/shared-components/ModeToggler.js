// ** MUI Imports
import IconButton from '@mui/material/IconButton'

// ** Icon Imports
import Icon from 'src/@core/components/icon'
import Tooltip from "@mui/material/Tooltip";
import { HomeContext } from "../../../../context/homeContext";
import {useContext} from "react";

const ModeToggler = props => {
  // ** Props
  const { settings, saveSettings } = props
  const {homeStore, setHomeStore} = useContext(HomeContext);

  const handleModeChange = mode => {
    saveSettings({ ...settings, mode: mode })
  }

  const handleModeToggle = () => {
    if (settings.mode === 'light') {
      handleModeChange('dark')
    } else {
      handleModeChange('light')
    }
  }

  return (
    <>
        <Tooltip title='Show Toolbar' >
          <IconButton
            disabled={homeStore.toolbarVisible}
            color='inherit' aria-haspopup='true' onClick={() => {
              window.triggerResizeEvent();
              setHomeStore((prev) => ({...prev, toolbarVisible: true}))
            }}>
            <Icon icon='gg:toolbar-top' />
          </IconButton>
        </Tooltip>
        <Tooltip title='Show Taskpane' >
          <IconButton
            disabled={homeStore.taskPaneVisible}
            color='inherit' aria-haspopup='true' onClick={() => {
              window.triggerResizeEvent();
              setHomeStore((prev) => ({...prev, taskPaneVisible: true}))
            }}>
            <Icon icon='tdesign:window' />
          </IconButton>
        </Tooltip>
    </>

    /*
        <IconButton color='inherit' aria-haspopup='true' onClick={handleModeToggle}>
          <Icon icon={settings.mode === 'dark' ? 'mdi:weather-sunny' : 'mdi:weather-night'} />
        </IconButton>
    */
  )
}

export default ModeToggler
