import * as GC from './dist/gc.spread.sheets';

export = GC;


