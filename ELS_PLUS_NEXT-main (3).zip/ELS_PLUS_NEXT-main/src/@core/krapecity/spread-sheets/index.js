module.exports = require('./dist/gc.spread.sheets.all.14.2.5.min.js');
