// @ts-ignore
export * from './dist/gc.spread.sheets.react';