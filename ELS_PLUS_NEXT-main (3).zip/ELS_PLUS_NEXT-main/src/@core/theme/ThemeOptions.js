// ** MUI Theme Provider
import { deepmerge } from '@mui/utils'

// ** User Theme Options
import UserThemeOptions from 'src/layouts/UserThemeOptions'

// ** Theme Override Imports
import palette from './palette'
import spacing from './spacing'
import shadows from './shadows'
import overrides from './overrides'
import typography from './typography'
import breakpoints from './breakpoints'

const themeOptions = (settings, overrideMode) => {
  // ** Vars
  const { skin, mode, direction, themeColor } = settings

  // ** Create New object before removing user component overrides and typography objects from userThemeOptions
  const userThemeConfig = Object.assign({}, UserThemeOptions())

  const mergedThemeConfig = deepmerge(
    {
      breakpoints: breakpoints(),
      direction,
      components: overrides(settings),
      palette: palette(mode === 'semi-dark' ? overrideMode : mode, skin),
      ...spacing,
      shape: {
        borderRadius: 10
      },
      mixins: {
        toolbar: {
          minHeight: 64
        }
      },
      shadows: shadows(mode === 'semi-dark' ? overrideMode : mode),
      typography
    },
    userThemeConfig
  )

  return deepmerge(mergedThemeConfig, {
    palette: {
      primary: {
        ...(mergedThemeConfig.palette
          ? mergedThemeConfig.palette[themeColor]
          : palette(mode === 'semi-dark' ? overrideMode : mode, skin).primary)
      }
    },
    components: {
      // Customizing the InputBase component will also affect TextField and Select
      MuiInputBase: {
        defaultProps: {
          size: 'small', // This affects the TextField size as well
        },
      },
      MuiSelect: {
        defaultProps: {
          size: 'small', // Make Select components small
        },
      },
      MuiTextField: {
        defaultProps: {
          size: 'small', // This will make all TextFields small
          margin: 'dense', // Reduce space around the component
        },
      },
      // If you are using TextareaAutosize separately, you would need to style it directly
      // since it does not have a size prop. Instead, you can use the `styleOverrides`
      // to adjust padding, margins, etc.
      MuiTextareaAutosize: {
        styleOverrides: {
          root: {
            // Adjust styles as needed for a smaller appearance
            padding: '8px',
            fontSize: '0.875rem', // Example to set to a smaller font size
          },
        },
      },
    }
  })
}

export default themeOptions
