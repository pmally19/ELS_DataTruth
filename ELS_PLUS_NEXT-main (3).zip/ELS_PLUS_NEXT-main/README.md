# ELS+ Web Interface

## Overview

ELS+ is a web-based interface that provides users with a spreadsheet-style environment to interact with various datasets and perform data analysis tasks. This tool integrates with multiple databases, including Google BigQuery, Snowflake, and Azure, allowing users to access, manipulate, and analyze data without switching between different database tools. With its Excel-like grid and rich set of actions, ELS+ makes complex data workflows accessible in a familiar and easy-to-use format.

## Features

- **Excel-Like Interface**: The application offers an intuitive grid layout resembling a spreadsheet, where users can input, view, and manipulate data.
- **Database Connectivity**: Seamless integration with Google BigQuery, Snowflake, and Azure, enabling easy access to large datasets from multiple sources.
- **Task Pane**: A customizable task pane provides options for users to filter, sort, and perform operations on selected datasets.
- **Dataset Actions**:
  - **New Dataset Creation**: Create new datasets directly within the app.
  - **Save and Commit**: Save changes or commit data back to the connected databases.
  - **Graphing and Scheduling**: Generate graphs and set up schedules for automated data operations.
  - **Model and Prediction**: Build, display, and use predictive models directly from the interface.
- **File Import**: Users can upload files (e.g., Excel sheets) to populate the grid.
- **Responsive Design**: The interface is designed to be flexible and responsive across different screen sizes.

## Project Structure

The main components of ELS+ are organized as follows:

- **UI Components**: Contains reusable components like buttons, dropdowns, and grids for a modular and consistent design.
- **Database Integrations**: Handles connections and queries for BigQuery, Snowflake, and Azure.
- **Task Pane**: Offers additional actions and customizable operations for enhanced data manipulation.
- **Toolbar**: Contains buttons and options for common actions like saving, graphing, and model building.

## Installation and Setup

To set up this project locally:

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/creativekdev/ELS_PLUS_NEXT.git
   cd ELS_PLUS_NEXT
2. **Install dependencies**:   
   ```bash
   npm install
3. **Run the application**:   
   ```bash
   npm run dev
4. **Access the application**: Open your web browser and navigate to http://localhost:3000.


